import { useEffect, useRef, useState } from "react";
import { api } from "./api";
import { useEditor } from "./store";
import { Media, newClip, uid, length, empty } from "./model";
import { Preview } from "./Preview";
import { Timeline } from "./Timeline";
import { Properties } from "./Properties";
import { readSrt, writeSrt } from "./srt";
const presets = ["minimal", "bold", "cinematic", "lower-third", "subtitle"];
export default function App() {
  const s = useEditor();
  const [tab, setTab] = useState("Media"),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(""),
    [progress, setProgress] = useState(0),
    [message, setMessage] = useState(""),
    [exact, setExact] = useState(""),
    [proxy, setProxy] = useState(false),
    [modal, setModal] = useState(""),
    [recents, setRecents] = useState<string[]>([]),
    [models, setModels] = useState<string[]>([]),
    [model, setModel] = useState("base"),
    [language, setLanguage] = useState("auto"),
    [roman, setRoman] = useState(false),
    [encoders, setEncoders] = useState(["libx264"]),
    [resolution, setResolution] = useState(1080),
    [quality, setQuality] = useState(20),
    [encoder, setEncoder] = useState("libx264"),
    [recording, setRecording] = useState(false);
  const recorder = useRef<MediaRecorder | null>(null),
    recStart = useRef(0),
    jobLock = useRef(false);
  const report = (e: unknown) =>
    setError(e instanceof Error ? e.message : String(e));
  async function safe(fn: () => Promise<unknown>) {
    try {
      await fn();
    } catch (e) {
      report(e);
    }
  }
  async function task(op: string, data: unknown) {
    if (jobLock.current)
      throw Error("Wait for the current task, or cancel it first.");
    jobLock.current = true;
    const id = uid();
    setBusy(id);
    setProgress(0);
    setMessage("Starting " + op + "…");
    s.play(false);
    try {
      return await api.job(id, op, data);
    } finally {
      setBusy("");
      jobLock.current = false;
    }
  }
  useEffect(
    () =>
      api.onProgress((p) => {
        setProgress(p.progress);
        setMessage(p.message);
      }),
    [],
  );
  useEffect(() => {
    safe(async () => {
      for (const path of await api.fonts()) {
        const name = path.includes("Arabic")
          ? "Noto Sans Arabic"
          : path.includes("Devanagari")
            ? "Noto Sans Devanagari"
            : "Noto Sans";
        const face = new FontFace(name, `url("${api.url(path)}")`);
        document.fonts.add(await face.load());
      }
      setRecents(await api.recent());
      let installed = await api.models();
      setModels(installed);
      if (installed.length) setModel(installed[0]);
    });
  }, []);
  useEffect(() => {
    setExact("");
    if (s.revision === 0) return;
    const timer = setTimeout(() => api.autosave(s.p).catch(report), 1500);
    return () => clearTimeout(timer);
  }, [s.revision]);
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (
        jobLock.current ||
        (e.target as HTMLElement).closest("input,textarea,select")
      )
        return;
      let handled = true;
      if (e.ctrlKey && e.key.toLowerCase() === "z") s.undo();
      else if (e.ctrlKey && e.key.toLowerCase() === "y") s.redo();
      else if (e.ctrlKey && e.key.toLowerCase() === "s")
        safe(async () => {
          await api.save(useEditor.getState().p);
        });
      else if (e.key.toLowerCase() === "s") s.split();
      else if (e.key === "Delete") s.remove();
      else if (e.code === "Space") s.play(!useEditor.getState().playing);
      else if (e.key === "ArrowRight")
        s.seek(useEditor.getState().time + 1 / s.p.fps);
      else if (e.key === "ArrowLeft")
        s.seek(useEditor.getState().time - 1 / s.p.fps);
      else handled = false;
      if (handled) e.preventDefault();
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [s.p.fps]);
  useEffect(() => {
    const fn = (e: BeforeUnloadEvent) => {
      if (useEditor.getState().revision > 0)
        api.autosave(useEditor.getState().p).catch(() => {});
      if (jobLock.current || recorder.current?.state === "recording") {
        e.preventDefault();
        e.returnValue = "A task is running.";
      }
    };
    window.addEventListener("beforeunload", fn);
    return () => window.removeEventListener("beforeunload", fn);
  }, []);
  function addMedia(media: Media[]) {
    s.edit((p) => {
      for (const m of media)
        if (!p.media.some((x) => x.id === m.id)) p.media.push(m);
    });
  }
  async function importMedia(paths?: string[]) {
    setMessage("Reading media and waveform…");
    const list = await api.importMedia(paths);
    addMedia(list);
    setNotice(list.length + " media files ready. Drag one onto a track.");
  }
  function addClip(m: Media) {
    s.edit((p) =>
      p.clips.push({
        ...newClip(m.kind, m.kind === "audio" ? 2 : 0, s.time),
        mediaId: m.id,
        duration: m.duration,
      }),
    );
  }
  function title(preset: string) {
    const c = { ...newClip("title", 1, s.time), style: preset };
    if (preset === "lower-third") {
      c.x = 0.12;
      c.y = 0.8;
      c.align = "left";
      c.fontSize = 48;
      c.box = true;
      c.animation = "slide";
    }
    if (preset === "cinematic") {
      c.fontSize = 88;
      c.text = "YOUR STORY";
    }
    if (preset === "bold") {
      c.fontSize = 100;
      c.animation = "pop";
    }
    if (preset === "subtitle") {
      c.y = 0.85;
      c.fontSize = 52;
      c.box = true;
    }
    s.edit((p) => p.clips.push(c));
    s.select(c.id);
  }
  async function voice() {
    if (recording) {
      recorder.current?.stop();
      return;
    }
    let stream = await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: false,
    });
    let chunks: BlobPart[] = [];
    let r = new MediaRecorder(stream);
    recorder.current = r;
    recStart.current = s.time;
    r.ondataavailable = (e) => chunks.push(e.data);
    r.onerror = () => {
      stream.getTracks().forEach((t) => t.stop());
      setRecording(false);
      setError(
        "Microphone recording failed. Check Windows microphone privacy settings.",
      );
    };
    r.onstop = () => {
      stream.getTracks().forEach((t) => t.stop());
      setRecording(false);
      safe(async () => {
        const media = await api.record(
          await new Blob(chunks, { type: r.mimeType }).arrayBuffer(),
        );
        addMedia([media]);
        s.edit((p) =>
          p.clips.push({
            ...newClip("audio", 2, recStart.current),
            mediaId: media.id,
            duration: media.duration,
          }),
        );
      });
    };
    r.start();
    setRecording(true);
  }
  return (
    <main
      className={busy ? "busy" : ""}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        if (!jobLock.current && e.dataTransfer.files.length) {
          e.preventDefault();
          safe(() => importMedia(api.paths(Array.from(e.dataTransfer.files))));
        }
      }}
    >
      <header>
        <div className="brand">
          <span>N</span> NextEra <b>STUDIO</b>
        </div>
        <input
          className="project-name"
          title="Project name"
          value={s.p.name}
          onChange={(e) =>
            s.edit((p) => {
              p.name = e.target.value;
            })
          }
        />
        <button
          title="Open a saved project JSON"
          onClick={() =>
            safe(async () => {
              let p = await api.open();
              if (p) s.load(p);
            })
          }
        >
          Open
        </button>
        <button
          title="Save project locally (Ctrl+S)"
          onClick={() =>
            safe(async () => {
              let path = await api.save(s.p);
              if (path) setNotice("Project saved.");
              setRecents(await api.recent());
            })
          }
        >
          Save
        </button>
        <button
          title="Save a copy to another file"
          onClick={() => safe(() => api.save(s.p, true))}
        >
          Save as
        </button>
        <button
          title="Recent projects and crash recovery"
          onClick={() => setModal("projects")}
        >
          Projects
        </button>
        <button
          title="Undo (Ctrl+Z)"
          disabled={!s.past.length}
          onClick={s.undo}
        >
          ↶
        </button>
        <button
          title="Redo (Ctrl+Y)"
          disabled={!s.future.length}
          onClick={s.redo}
        >
          ↷
        </button>
        <button
          className="accent"
          title="Export an MP4 without a watermark"
          disabled={!!busy || !s.p.clips.length}
          onClick={() => {
            setModal("export");
            safe(async () => setEncoders(await task("encoders", {})));
          }}
        >
          Export MP4 ↗
        </button>
      </header>
      {error && (
        <div role="alert" className="banner error">
          <span>{error}</span>
          <button title="Dismiss error" onClick={() => setError("")}>
            ×
          </button>
        </div>
      )}
      {notice && (
        <div className="banner">
          <span>{notice}</span>
          <button title="Dismiss notification" onClick={() => setNotice("")}>
            ×
          </button>
        </div>
      )}
      <div className="workspace">
        <aside className="library">
          <nav>
            {["Media", "Titles", "Captions"].map((t) => (
              <button
                title={"Open " + t + " library"}
                className={tab === t ? "active" : ""}
                key={t}
                onClick={() => setTab(t)}
              >
                {t}
              </button>
            ))}
          </nav>
          {tab === "Media" && (
            <>
              <div className="row">
                <button
                  className="accent"
                  title="Import video, audio or images"
                  onClick={() => safe(() => importMedia())}
                >
                  + Import media
                </button>
                <button
                  title="Record a voiceover at the playhead"
                  className={recording ? "danger" : ""}
                  onClick={() => safe(voice)}
                >
                  {recording ? "■ Stop" : "● Voice"}
                </button>
              </div>
              <div className="media-grid">
                {s.p.media.map((m) => (
                  <div
                    className="media-card"
                    key={m.id}
                    draggable
                    onDragStart={(e) => e.dataTransfer.setData("media", m.id)}
                    onDoubleClick={() => addClip(m)}
                    title="Drag to a track or double-click to add at the playhead"
                  >
                    <div className="thumbnail">
                      {m.kind === "image" ? (
                        <img src={api.url(m.path)} />
                      ) : m.kind === "video" ? (
                        <video
                          src={api.url(m.proxy || m.path)}
                          preload="metadata"
                          muted
                        />
                      ) : (
                        <span>♫</span>
                      )}
                      <small>{m.kind}</small>
                    </div>
                    <b>{m.name}</b>
                    <small>{m.duration.toFixed(1)} seconds</small>
                  </div>
                ))}
              </div>
              {!s.p.media.length && (
                <div className="empty">
                  <strong>Drop your first video here</strong>
                  <p>Videos, music, photos—everything stays on your laptop.</p>
                </div>
              )}
            </>
          )}
          {tab === "Titles" && (
            <>
              <p className="muted">Click a design to add it at the playhead.</p>
              {presets.map((t) => (
                <button
                  key={t}
                  title={"Add " + t + " title"}
                  className={"title-preset " + t}
                  onClick={() => title(t)}
                >
                  {t === "cinematic"
                    ? "YOUR STORY"
                    : t === "lower-third"
                      ? "Your name / Your story"
                      : t}
                </button>
              ))}
            </>
          )}
          {tab === "Captions" && (
            <>
              <h3>Say it. Caption it.</h3>
              <p className="muted">
                Local speech recognition. English, Urdu and Hindi.
              </p>
              <button
                className="accent wide"
                title="Generate timed captions from all audible timeline clips"
                disabled={!!busy}
                onClick={() => setModal("captions")}
              >
                ✦ Auto Captions
              </button>
              <button
                className="wide"
                title="Import subtitle timing and text"
                onClick={() =>
                  safe(async () => {
                    let t = await api.readSrt();
                    if (t) s.edit((p) => p.clips.push(...readSrt(t, 1)));
                  })
                }
              >
                Import .srt
              </button>
              <button
                className="wide"
                title="Export all caption clips as subtitles"
                onClick={() => safe(() => api.writeSrt(writeSrt(s.p.clips)))}
              >
                Export .srt
              </button>
              <p className="muted">
                Select a caption to edit text, timing and highlight colours.
                Proofread names and Roman Urdu.
              </p>
            </>
          )}
        </aside>
        <section className="viewer">
          <div className="viewer-toolbar">
            <select
              title="Project aspect ratio"
              value={s.p.aspect}
              onChange={(e) =>
                s.edit((p) => {
                  p.aspect = e.target.value;
                })
              }
            >
              {["16:9", "9:16", "1:1", "4:5"].map((r) => (
                <option key={r}>{r}</option>
              ))}
            </select>
            <span className="muted">
              {exact
                ? "Rendered preview • export pipeline"
                : "Fast preview • approximate effects"}
            </span>
            <button
              title="Render a low-resolution preview using the exact export filters"
              disabled={!!busy || !s.p.clips.length}
              onClick={() =>
                safe(async () => {
                  let result = await task("preview", {
                    project: s.p,
                    settings: { fps: s.p.fps },
                  });
                  if (result) setExact(result);
                })
              }
            >
              Render preview
            </button>
            {exact && (
              <button
                title="Return to responsive editing preview"
                onClick={() => setExact("")}
              >
                Fast
              </button>
            )}
          </div>
          <div className="stage-wrap">
            <Preview exact={exact} proxy={proxy} />
          </div>
          <div className="transport">
            <button
              title="Previous frame (Left arrow)"
              onClick={() => {
                s.play(false);
                s.seek(s.time - 1 / s.p.fps);
              }}
            >
              │◀
            </button>
            <button
              className="play"
              title="Play or pause (Space)"
              onClick={() => s.play(!s.playing)}
            >
              {s.playing ? "Ⅱ" : "▶"}
            </button>
            <button
              title="Next frame (Right arrow)"
              onClick={() => {
                s.play(false);
                s.seek(s.time + 1 / s.p.fps);
              }}
            >
              ▶│
            </button>
            <span>
              {s.time.toFixed(2)} / {length(s.p).toFixed(2)} s
            </span>
            <label>
              <input
                type="checkbox"
                checked={proxy}
                title="Use generated 640-pixel proxy videos for fast preview"
                onChange={(e) => {
                  setProxy(e.target.checked);
                  if (e.target.checked)
                    safe(async () => {
                      for (const m of s.p.media.filter(
                        (m) => m.kind === "video" && !m.proxy,
                      )) {
                        const path = await task("proxy", { path: m.path });
                        s.edit((p) => {
                          let item = p.media.find((x) => x.id === m.id);
                          if (item) item.proxy = path;
                        });
                      }
                    });
                }}
              />
              Low-res preview
            </label>
          </div>
          <input
            className="scrub"
            title="Seek timeline"
            type="range"
            min="0"
            max={length(s.p)}
            step={1 / s.p.fps}
            value={s.time}
            onChange={(e) => s.seek(+e.target.value)}
          />
        </section>
        <Properties />
      </div>
      <Timeline />
      <footer>
        <span>LOCAL • NO WATERMARK</span>
        <span>
          Autosave after edits • S: split • Space: play • Ctrl+Z: undo
        </span>
        <span>v0.1 • experimental</span>
      </footer>
      {!!busy && (
        <div className="progress">
          <span>{message}</span>
          <progress value={progress} max="1" />
          <b>{Math.round(progress * 100)}%</b>
          <button
            title="Cancel current processing task"
            onClick={() => safe(() => api.cancel(busy))}
          >
            Cancel
          </button>
        </div>
      )}
      {!!modal && (
        <div className="modal-backdrop">
          <section className="modal">
            <button
              className="close"
              title="Close dialog"
              onClick={() => setModal("")}
            >
              ×
            </button>
            {modal === "captions" && (
              <>
                <h2>Auto Captions</h2>
                <p>
                  Transcribe the audible timeline mix entirely on this laptop.
                </p>
                <label className="field">
                  Model
                  <select
                    title="Speech model size"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                  >
                    {["tiny", "base", "small", "medium"].map((m) => (
                      <option key={m} value={m}>
                        {m}
                        {models.includes(m)
                          ? " • installed"
                          : " • install first"}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  Language
                  <select
                    title="Spoken language"
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                  >
                    <option value="auto">Detect automatically</option>
                    <option value="en">English</option>
                    <option value="ur">Urdu</option>
                    <option value="hi">Hindi</option>
                  </select>
                </label>
                <label className="check">
                  <input
                    type="checkbox"
                    checked={roman}
                    onChange={(e) => setRoman(e.target.checked)}
                  />
                  Roman Urdu approximation (Urdu speech)
                </label>
                <p className="muted">
                  Base is a good first test. Small/medium are slower. Install a
                  model once using the included model-download script. Generated
                  captions are added; existing captions remain.
                </p>
                <button
                  className="accent"
                  title="Start offline transcription"
                  disabled={
                    !!busy || !models.includes(model) || !s.p.clips.length
                  }
                  onClick={() =>
                    safe(async () => {
                      setModal("");
                      const results = await task("captions", {
                        project: s.p,
                        model,
                        language,
                        roman,
                      });
                      s.edit((p) => {
                        let track = Math.max(...p.tracks.map((t) => t.id)) + 1;
                        p.tracks.push({ id: track, name: "Auto captions" });
                        p.clips.push(
                          ...results.map((r: any) => ({
                            ...newClip("caption", track, r.start),
                            ...r,
                            font:
                              language === "hi"
                                ? "Noto Sans Devanagari"
                                : language === "ur" && !roman
                                  ? "Noto Sans Arabic"
                                  : "Noto Sans",
                            style: "highlight",
                            animation: "none",
                          })),
                        );
                      });
                      setNotice(
                        results.length + " captions added. Please proofread.",
                      );
                    })
                  }
                >
                  Generate captions
                </button>
              </>
            )}
            {modal === "export" && (
              <>
                <h2>Your movie, no watermark.</h2>
                <label className="field">
                  Resolution
                  <select
                    title="Export resolution"
                    value={resolution}
                    onChange={(e) => setResolution(+e.target.value)}
                  >
                    {[720, 1080, 2160].map((v) => (
                      <option key={v} value={v}>
                        {v === 2160 ? "4K" : v + "p"}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  Frame rate
                  <select
                    title="Export frames per second"
                    value={s.p.fps}
                    onChange={(e) =>
                      s.edit((p) => {
                        p.fps = +e.target.value;
                      })
                    }
                  >
                    {[24, 25, 30, 50, 60].map((v) => (
                      <option key={v}>{v}</option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  Quality
                  <select
                    title="Smaller quality number means a larger, sharper file"
                    value={quality}
                    onChange={(e) => setQuality(+e.target.value)}
                  >
                    <option value="18">High quality • large file</option>
                    <option value="20">Recommended</option>
                    <option value="25">Smaller file</option>
                  </select>
                </label>
                <label className="field">
                  Encoder
                  <select
                    title="Only encoders that pass a local hardware test appear"
                    value={encoder}
                    onChange={(e) => setEncoder(e.target.value)}
                  >
                    {encoders.map((v) => (
                      <option key={v} value={v}>
                        {v === "libx264" ? "Software H.264 (reliable)" : v}
                      </option>
                    ))}
                  </select>
                </label>
                <p className="muted">
                  Original sources are used even with proxies enabled. Hardware
                  encoding needs a compatible GPU and driver.
                </p>
                <button
                  className="accent"
                  title="Choose output location and render MP4"
                  disabled={!!busy}
                  onClick={() =>
                    safe(async () => {
                      setModal("");
                      let out = await task("export", {
                        project: s.p,
                        settings: {
                          resolution,
                          fps: s.p.fps,
                          quality,
                          encoder,
                        },
                      });
                      if (out) setNotice("Export complete: " + out);
                    })
                  }
                >
                  Choose file & export
                </button>
              </>
            )}
            {modal === "projects" && (
              <>
                <h2>Your projects</h2>
                <button
                  className="wide"
                  title="Recover the last local autosave"
                  onClick={() =>
                    safe(async () => {
                      let p = await api.recover();
                      if (p) {
                        s.load(p);
                        setModal("");
                      } else setNotice("No autosave found yet.");
                    })
                  }
                >
                  Recover autosave
                </button>
                {recents.map((path) => (
                  <button
                    className="wide recent"
                    title={path}
                    key={path}
                    onClick={() =>
                      safe(async () => {
                        let p = await api.open(path);
                        if (p) {
                          s.load(p);
                          setModal("");
                        }
                      })
                    }
                  >
                    {path}
                  </button>
                ))}
                <button
                  className="wide"
                  title="Save current work before starting a new project"
                  onClick={() =>
                    safe(async () => {
                      let saved = await api.save(s.p);
                      if (saved) {
                        await api.newProject();
                        s.load(empty());
                        setModal("");
                      }
                    })
                  }
                >
                  Save current & start new
                </button>
              </>
            )}
          </section>
        </div>
      )}
    </main>
  );
}
