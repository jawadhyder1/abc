import { useEffect, useRef } from "react";
import { api } from "./api";
import { useEditor } from "./store";
import { length, valueAt, Clip } from "./model";
export function Preview({ exact, proxy }: { exact: string; proxy: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null),
    master = useRef<HTMLVideoElement>(null),
    sources = useRef(new Map<string, HTMLVideoElement | HTMLImageElement>());
  const { p, time, playing, selected, patch } = useEditor();
  useEffect(() => {
    const map = sources.current;
    return () => {
      for (const el of map.values())
        if (el instanceof HTMLVideoElement) {
          el.pause();
          el.removeAttribute("src");
          el.load();
        }
      map.clear();
    };
  }, []);
  useEffect(() => {
    if (!master.current || !exact) return;
    let v = master.current;
    if (Math.abs(v.currentTime - time) > 0.25) v.currentTime = time;
    playing
      ? v.play().catch(() => useEditor.getState().play(false))
      : v.pause();
  }, [time, playing, exact]);
  useEffect(() => {
    let frame = 0,
      last = performance.now();
    const paint = (now: number) => {
      let s = useEditor.getState();
      if (s.playing && !exact) {
        let next = s.time + Math.min(0.1, (now - last) / 1000);
        if (next >= length(s.p)) {
          s.play(false);
          s.seek(length(s.p));
        } else s.seek(next);
      }
      last = now;
      const cvs = canvas.current,
        ctx = cvs?.getContext("2d");
      if (!ctx || !cvs) return;
      let [a, b] = s.p.aspect.split(":").map(Number);
      cvs.width = 960;
      cvs.height = Math.round((960 * b) / a);
      const w = cvs.width,
        h = cvs.height;
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, w, h);
      const active = s.p.clips
        .filter((c) => s.time >= c.start && s.time < c.start + c.duration)
        .sort(
          (a, b) =>
            Number(["title", "caption"].includes(a.kind)) -
              Number(["title", "caption"].includes(b.kind)) ||
            a.track - b.track ||
            a.start - b.start,
        );
      const activeIds = new Set(active.map((c) => c.id));
      for (const [id, el] of sources.current)
        if (el instanceof HTMLVideoElement && (!activeIds.has(id) || exact))
          el.pause();
      if (!exact)
        for (const c of active) {
          const t = s.time - c.start;
          let scale = valueAt(c, "scale", t) * (1 + (c.zoom * t) / c.duration),
            alpha = valueAt(c, "opacity", t),
            x = valueAt(c, "x", t) * w,
            y = valueAt(c, "y", t) * h;
          let enter = Math.min(1, t / Math.max(0.01, c.transitionDuration)),
            leave = Math.min(
              1,
              (c.duration - t) / Math.max(0.01, c.transitionDuration),
            );
          if (["fade", "dissolve"].includes(c.transition))
            alpha *= Math.min(enter, leave);
          if (c.transition === "slide") x -= w * (1 - enter);
          if (c.transition === "zoom") scale *= 0.5 + 0.5 * enter;
          x += c.shake * w * 0.015 * Math.sin(t * 43);
          y += c.shake * h * 0.015 * Math.cos(t * 37);
          if (c.kind === "title" || c.kind === "caption") {
            drawText(ctx, c, t, w, h, x, y, alpha, scale);
            continue;
          }
          const m = s.p.media.find((m) => m.id === c.mediaId);
          if (!m) continue;
          let el = sources.current.get(c.id);
          const src = api.url(proxy && m.proxy ? m.proxy : m.path);
          if (!el) {
            el =
              c.kind === "image"
                ? new Image()
                : document.createElement("video");
            if (el instanceof HTMLVideoElement) {
              el.preload = "auto";
              el.playsInline = true;
            }
            el.src = src;
            sources.current.set(c.id, el);
          }
          if (el.src !== src) el.src = src;
          if (el instanceof HTMLVideoElement) {
            let desired = c.in + (c.reverse ? c.duration - t : t) * c.speed;
            if (
              Number.isFinite(el.duration) &&
              Math.abs(el.currentTime - desired) >
                (s.playing && !c.reverse ? 0.18 : 0.025)
            )
              el.currentTime = Math.min(
                Math.max(0, desired),
                Math.max(0, el.duration - 0.001),
              );
            el.playbackRate = c.speed;
            let fade = Math.min(
              c.fadeIn ? t / c.fadeIn : 1,
              c.fadeOut ? (c.duration - t) / c.fadeOut : 1,
              1,
            );
            el.volume = Math.max(0, Math.min(1, c.volume * fade));
            el.muted = c.mute || c.reverse;
            if (s.playing && !c.reverse) el.play().catch(() => {});
            else el.pause();
            if (el.readyState < 2) continue;
          } else if (!el.complete || !el.naturalWidth) continue;
          if (c.kind === "audio") continue;
          let sw = m.width || w,
            sh = m.height || h,
            fit = Math.min(w / sw, h / sh);
          ctx.save();
          ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
          ctx.translate(x, y);
          ctx.rotate((c.rotate * Math.PI) / 180);
          ctx.scale(scale * (c.flip ? -1 : 1), scale);
          if (c.transition === "wipe") {
            ctx.beginPath();
            ctx.rect(-w / 2, -h / 2, w * enter, h);
            ctx.clip();
          }
          if (c.backgroundBlur) {
            ctx.save();
            ctx.filter = "blur(22px)";
            let fill = Math.max(w / sw, h / sh);
            ctx.drawImage(
              el,
              (-sw * fill) / 2,
              (-sh * fill) / 2,
              sw * fill,
              sh * fill,
            );
            ctx.restore();
          }
          ctx.filter = `brightness(${1 + c.brightness}) contrast(${c.contrast}) saturate(${c.grayscale ? 0 : c.saturation}) blur(${(c.blur * h) / 1080}px) sepia(${Math.abs(c.temperature) * 0.25})`;
          let crop = Math.max(0, Math.min(0.45, c.crop));
          ctx.drawImage(
            el,
            sw * crop,
            sh * crop,
            sw * (1 - 2 * crop),
            sh * (1 - 2 * crop),
            (-sw * fit) / 2,
            (-sh * fit) / 2,
            sw * fit,
            sh * fit,
          );
          ctx.filter = "none";
          if (c.vignette) {
            let g = ctx.createRadialGradient(0, 0, h * 0.15, 0, 0, w * 0.6);
            g.addColorStop(0, "transparent");
            g.addColorStop(1, `rgba(0,0,0,${c.vignette * 0.8})`);
            ctx.fillStyle = g;
            ctx.fillRect(-w / 2, -h / 2, w, h);
          }
          if (c.mask.enabled) {
            const m = c.mask;
            ctx.save();
            ctx.beginPath();
            ctx.rect((m.x - 0.5) * w, (m.y - 0.5) * h, m.w * w, m.h * h);
            ctx.clip();
            ctx.filter = m.mode === "blur" ? "blur(16px)" : "none";
            if (m.mode === "mosaic") {
              const small = document.createElement("canvas");
              small.width = 40;
              small.height = 24;
              small.getContext("2d")!.drawImage(el, 0, 0, 40, 24);
              ctx.imageSmoothingEnabled = false;
              ctx.drawImage(
                small,
                (-sw * fit) / 2,
                (-sh * fit) / 2,
                sw * fit,
                sh * fit,
              );
            } else
              ctx.drawImage(
                el,
                (-sw * fit) / 2,
                (-sh * fit) / 2,
                sw * fit,
                sh * fit,
              );
            ctx.restore();
          }
          ctx.restore();
        }
      frame = requestAnimationFrame(paint);
    };
    frame = requestAnimationFrame(paint);
    return () => cancelAnimationFrame(frame);
  }, [exact, proxy]);
  return (
    <div
      className="preview-stage"
      style={{ aspectRatio: p.aspect.replace(":", "/") }}
    >
      <canvas
        ref={canvas}
        hidden={!!exact}
        title="Fast preview. Drag selected title, or its enabled privacy box, to reposition."
        onPointerDown={(e) => {
          let c = p.clips.find((c) => c.id === selected);
          if (!c || exact) return;
          const r = e.currentTarget.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width,
            y = (e.clientY - r.top) / r.height;
          if (c.mask.enabled)
            patch(c.id, {
              mask: {
                ...c.mask,
                x: Math.max(0, Math.min(1 - c.mask.w, x - c.mask.w / 2)),
                y: Math.max(0, Math.min(1 - c.mask.h, y - c.mask.h / 2)),
              },
            });
          else patch(c.id, { x, y });
        }}
      />
      {exact && (
        <video
          ref={master}
          src={api.url(exact)}
          onTimeUpdate={(e) => {
            if (playing) useEditor.getState().seek(e.currentTarget.currentTime);
          }}
          onEnded={() => useEditor.getState().play(false)}
        />
      )}
    </div>
  );
}
function drawText(
  ctx: CanvasRenderingContext2D,
  c: Clip,
  t: number,
  w: number,
  h: number,
  x: number,
  y: number,
  alpha: number,
  scale: number,
) {
  const fade = Math.min(1, t / 0.3, (c.duration - t) / 0.3);
  if (c.animation === "fade") alpha *= fade;
  if (c.animation === "slide") x -= w * 0.2 * (1 - Math.min(1, t / 0.3));
  if (c.animation === "pop") scale *= 0.65 + 0.35 * Math.min(1, t / 0.3);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((c.rotate * Math.PI) / 180);
  ctx.scale(scale, scale);
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  let size = (c.fontSize * h) / 1080;
  ctx.font = `${["bold", "cinematic"].includes(c.style) ? "bold " : ""}${size}px "${c.font}", sans-serif`;
  ctx.textAlign = c.align as CanvasTextAlign;
  ctx.textBaseline = "middle";
  ctx.lineWidth = (c.outline * h) / 540;
  ctx.strokeStyle = "#000";
  ctx.shadowColor = "#000";
  ctx.shadowBlur = c.shadow;
  ctx.fillStyle = c.color;
  let text =
    c.animation === "typewriter"
      ? c.text.slice(
          0,
          Math.max(
            1,
            Math.ceil((c.text.length * t) / Math.min(1.5, c.duration * 0.6)),
          ),
        )
      : c.text;
  let lines = text.split("\n");
  for (let i = 0; i < lines.length; i++) {
    let yy = (i - (lines.length - 1) / 2) * size * 1.3;
    let width = ctx.measureText(lines[i]).width;
    if (c.box || c.style === "boxed") {
      ctx.fillStyle = "#151515cc";
      ctx.fillRect(
        c.align === "left"
          ? -8
          : c.align === "right"
            ? -width - 8
            : -width / 2 - 8,
        yy - size * 0.65,
        width + 16,
        size * 1.3,
      );
      ctx.fillStyle = c.color;
    }
    if (c.outline) ctx.strokeText(lines[i], 0, yy);
    ctx.fillText(lines[i], 0, yy);
    if (c.words.length && ["highlight", "karaoke"].includes(c.style)) {
      let cursor =
        c.align === "left" ? 0 : c.align === "right" ? -width : -width / 2;
      ctx.textAlign = "left";
      for (const word of c.words) {
        if (t >= word.start && (c.style === "karaoke" || t < word.end)) {
          ctx.fillStyle = c.highlight;
          ctx.fillText(word.word + " ", cursor, yy);
        }
        cursor += ctx.measureText(word.word + " ").width;
      }
    }
  }
  ctx.restore();
}
