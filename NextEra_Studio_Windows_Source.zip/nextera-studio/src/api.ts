import type { Project, Media } from "./model";
export type Progress = { id: string; progress: number; message: string };
export type API = {
  paths: (files: File[]) => string[];
  importMedia: (paths?: string[]) => Promise<Media[]>;
  url: (path: string) => string;
  save: (p: Project, as?: boolean) => Promise<string | null>;
  open: (path?: string) => Promise<Project | null>;
  recent: () => Promise<string[]>;
  autosave: (p: Project) => Promise<void>;
  recover: () => Promise<Project | null>;
  job: (id: string, op: string, data: unknown) => Promise<any>;
  cancel: (id: string) => Promise<void>;
  onProgress: (fn: (p: Progress) => void) => () => void;
  readSrt: () => Promise<string | null>;
  writeSrt: (text: string) => Promise<void>;
  record: (bytes: ArrayBuffer) => Promise<Media>;
  newProject: () => Promise<void>;
  fonts: () => Promise<string[]>;
  models: () => Promise<string[]>;
};
declare global {
  interface Window {
    studio: API;
  }
}
export const api = window.studio;
