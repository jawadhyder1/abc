import { create } from "zustand";
import { empty, Project, Clip, splitClip } from "./model";
type State = {
  p: Project;
  selected: string;
  time: number;
  playing: boolean;
  zoom: number;
  past: Project[];
  future: Project[];
  revision: number;
  edit: (fn: (p: Project) => void) => void;
  patch: (id: string, p: Partial<Clip>) => void;
  select: (id: string) => void;
  seek: (n: number) => void;
  play: (b: boolean) => void;
  load: (p: Project) => void;
  undo: () => void;
  redo: () => void;
  split: () => void;
  remove: () => void;
};
export const useEditor = create<State>((set, get) => ({
  p: empty(),
  selected: "",
  time: 0,
  playing: false,
  zoom: 65,
  past: [],
  future: [],
  revision: 0,
  edit: (fn) =>
    set((s) => {
      let p = structuredClone(s.p);
      fn(p);
      return {
        p,
        past: [...s.past.slice(-79), s.p],
        future: [],
        revision: s.revision + 1,
      };
    }),
  patch: (id, patch) =>
    get().edit((p) => {
      let c = p.clips.find((c) => c.id === id);
      if (c) Object.assign(c, patch);
    }),
  select: (selected) => set({ selected }),
  seek: (time) => set({ time: Math.max(0, time) }),
  play: (playing) => set({ playing }),
  load: (p) =>
    set((s) => ({
      p,
      past: [],
      future: [],
      selected: "",
      time: 0,
      playing: false,
      revision: s.revision + 1,
    })),
  undo: () =>
    set((s) =>
      s.past.length
        ? {
            p: s.past.at(-1)!,
            past: s.past.slice(0, -1),
            future: [s.p, ...s.future],
            revision: s.revision + 1,
          }
        : {},
    ),
  redo: () =>
    set((s) =>
      s.future.length
        ? {
            p: s.future[0],
            past: [...s.past, s.p],
            future: s.future.slice(1),
            revision: s.revision + 1,
          }
        : {},
    ),
  split: () =>
    get().edit((p) => {
      p.clips = p.clips.flatMap((c) =>
        c.id === get().selected ? splitClip(c, get().time) : [c],
      );
    }),
  remove: () =>
    get().edit((p) => {
      p.clips = p.clips.filter((c) => c.id !== get().selected);
    }),
}));
