import { useRef, useState } from "react";
import { useEditor } from "./store";
import { length, newClip, Clip, sliceClip } from "./model";
export function Timeline() {
  const { p, selected, time, zoom, select, seek, edit, patch } = useEditor();
  const [snap, setSnap] = useState(true);
  const drag = useRef<{ clip: Clip; x: number; mode: string } | null>(null);
  const [ghost, setGhost] = useState<Clip | null>(null);
  const end = Math.max(30, length(p) + 8),
    width = end * zoom;
  function snapped(n: number, c: Clip) {
    if (!snap) return Math.max(0, n);
    const points = [
      0,
      time,
      ...p.clips
        .filter((a) => a.id !== c.id)
        .flatMap((a) => [a.start, a.start + a.duration]),
    ];
    let closest = points.sort((a, b) => Math.abs(a - n) - Math.abs(b - n))[0];
    return Math.max(0, Math.abs(closest - n) < 8 / zoom ? closest : n);
  }
  function move(e: React.PointerEvent) {
    let d = drag.current;
    if (!d) return;
    let delta = (e.clientX - d.x) / zoom,
      c = { ...d.clip };
    if (d.mode === "move") {
      c.start = snapped(c.start + delta, c);
      const row = document
        .elementFromPoint(e.clientX, e.clientY)
        ?.closest("[data-track]");
      if (row) c.track = Number((row as HTMLElement).dataset.track);
    }
    const media = p.media.find((m) => m.id === c.mediaId);
    const finite = media && c.kind !== "image";
    if (d.mode === "left") {
      const available = finite
        ? c.reverse
          ? (media.duration - c.in - c.duration * c.speed) / c.speed
          : c.in / c.speed
        : c.start;
      delta = Math.max(
        -c.start,
        -available,
        Math.min(c.duration - 0.04, delta),
      );
      c = sliceClip(c, delta, c.duration - delta);
    }
    if (d.mode === "right") {
      const maximum = finite
        ? c.reverse
          ? c.duration + c.in / c.speed
          : (media.duration - c.in) / c.speed
        : 86400;
      c = sliceClip(
        c,
        0,
        Math.max(0.04, Math.min(maximum, c.duration + delta)),
      );
    }
    setGhost(c);
  }
  function commit() {
    if (ghost) patch(ghost.id, ghost);
    drag.current = null;
    setGhost(null);
  }
  return (
    <section className="timeline">
      <div className="timeline-tools">
        <b>Timeline</b>
        <button
          title="Split selected clip at playhead (S)"
          onClick={() => useEditor.getState().split()}
        >
          ✂ Split
        </button>
        <button
          title="Delete selected clip (Delete)"
          onClick={() => useEditor.getState().remove()}
        >
          Delete
        </button>
        <button
          title="Add another visual or audio layer"
          onClick={() =>
            edit((p) => {
              let id = Math.max(...p.tracks.map((t) => t.id)) + 1;
              p.tracks.push({ id, name: "Track " + (id + 1) });
            })
          }
        >
          + Track
        </button>
        <label>
          <input
            type="checkbox"
            checked={snap}
            onChange={(e) => setSnap(e.target.checked)}
          />{" "}
          Snap
        </label>
        <label>
          Zoom{" "}
          <input
            type="range"
            min="15"
            max="180"
            value={zoom}
            onChange={(e) => useEditor.setState({ zoom: +e.target.value })}
          />
        </label>
        <span className="muted">
          Higher numbered tracks appear on top • drag edges to trim
        </span>
      </div>
      <div className="timeline-scroll">
        <div style={{ width: width + 130, minWidth: "100%" }}>
          <div
            className="ruler"
            style={{ marginLeft: 130, width }}
            onPointerDown={(e) =>
              seek(
                (e.clientX - e.currentTarget.getBoundingClientRect().left) /
                  zoom,
              )
            }
          >
            {Array.from({ length: Math.ceil(end) }, (_, i) => (
              <span key={i} style={{ left: i * zoom }}>
                {i % 5 === 0 ? i + "s" : "·"}
              </span>
            ))}
          </div>
          {p.tracks
            .slice()
            .reverse()
            .map((track) => (
              <div className="track" data-track={track.id} key={track.id}>
                <div className="track-label">{track.name}</div>
                <div
                  className="track-body"
                  style={{ width }}
                  onPointerDown={(e) => {
                    if (e.target === e.currentTarget)
                      seek(
                        (e.clientX -
                          e.currentTarget.getBoundingClientRect().left) /
                          zoom,
                      );
                  }}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const id = e.dataTransfer.getData("media");
                    const m = p.media.find((m) => m.id === id);
                    if (!m) return;
                    const t =
                      (e.clientX -
                        e.currentTarget.getBoundingClientRect().left) /
                      zoom;
                    edit((p) =>
                      p.clips.push({
                        ...newClip(m.kind, track.id, Math.max(0, t)),
                        mediaId: m.id,
                        duration: m.duration,
                      }),
                    );
                  }}
                >
                  {p.clips
                    .filter((c) => c.track === track.id)
                    .map((original) => {
                      let c = ghost?.id === original.id ? ghost : original,
                        m = p.media.find((m) => m.id === c.mediaId);
                      return (
                        <div
                          key={c.id}
                          className={`clip ${c.kind} ${selected === c.id ? "selected" : ""}`}
                          style={{
                            left: c.start * zoom,
                            width: Math.max(4, c.duration * zoom),
                          }}
                          title={`${m?.name || c.text}\n${c.start.toFixed(2)}s • ${c.duration.toFixed(2)}s`}
                          onPointerDown={(e) => {
                            e.stopPropagation();
                            select(c.id);
                            drag.current = {
                              clip: structuredClone(c),
                              x: e.clientX,
                              mode:
                                (e.target as HTMLElement).dataset.edge ||
                                "move",
                            };
                            e.currentTarget.setPointerCapture(e.pointerId);
                          }}
                          onPointerMove={move}
                          onPointerUp={commit}
                          onPointerCancel={() => {
                            drag.current = null;
                            setGhost(null);
                          }}
                        >
                          <i className="handle left" data-edge="left" />
                          <span>{m?.name || c.text}</span>
                          {!!m?.waveform.length && (
                            <svg
                              viewBox="0 0 400 30"
                              preserveAspectRatio="none"
                            >
                              <path
                                d={m.waveform
                                  .map(
                                    (v, i) =>
                                      `M${(i * 400) / m.waveform.length},${15 - v * 14}v${v * 28}`,
                                  )
                                  .join(" ")}
                                stroke="currentColor"
                                strokeWidth="1"
                              />
                            </svg>
                          )}
                          <i className="handle right" data-edge="right" />
                        </div>
                      );
                    })}
                  <div className="playhead" style={{ left: time * zoom }} />
                </div>
              </div>
            ))}
        </div>
      </div>
    </section>
  );
}
