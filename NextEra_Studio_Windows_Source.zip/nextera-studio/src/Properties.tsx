import { useEditor } from "./store";
import { Clip, valueAt } from "./model";
export function Properties() {
  const { p, selected, patch, time } = useEditor(),
    c = p.clips.find((c) => c.id === selected);
  if (!c)
    return (
      <aside className="properties">
        <h3>Make it yours</h3>
        <p className="muted">
          Select any timeline clip to change its timing, look, sound or text.
        </p>
        <p>Start by importing a video, then drag it onto a track.</p>
        <p>
          Press <kbd>S</kbd> to split at the playhead.
        </p>
      </aside>
    );
  const set = (key: keyof Clip, value: unknown) =>
    patch(c.id, { [key]: value });
  const num = (
    label: string,
    key: keyof Clip,
    min: number,
    max: number,
    step = 0.01,
  ) => (
    <label className="field" key={key}>
      <span>{label}</span>
      <input
        title={label}
        type="number"
        min={min}
        max={max}
        step={step}
        value={c[key] as number}
        onChange={(e) => {
          let v = +e.target.value;
          if (Number.isFinite(v)) set(key, Math.min(max, Math.max(min, v)));
        }}
      />
    </label>
  );
  const slider = (
    label: string,
    key: keyof Clip,
    min: number,
    max: number,
    step = 0.01,
  ) => (
    <label className="slider" key={key}>
      <span>
        {label}
        <small>{Number(c[key]).toFixed(2)}</small>
      </span>
      <input
        title={label}
        type="range"
        min={min}
        max={max}
        step={step}
        value={c[key] as number}
        onChange={(e) => set(key, +e.target.value)}
      />
    </label>
  );
  const check = (label: string, key: keyof Clip) => (
    <label className="check" key={key}>
      <input
        title={label}
        type="checkbox"
        checked={!!c[key]}
        onChange={(e) => set(key, e.target.checked)}
      />
      {label}
    </label>
  );
  const choice = (label: string, key: keyof Clip, values: string[]) => (
    <label className="field">
      <span>{label}</span>
      <select
        title={label}
        value={c[key] as string}
        onChange={(e) => set(key, e.target.value)}
      >
        {values.map((v) => (
          <option key={v}>{v}</option>
        ))}
      </select>
    </label>
  );
  const text = c.kind === "title" || c.kind === "caption";
  const m = p.media.find((m) => m.id === c.mediaId);
  return (
    <aside className="properties">
      <h3>{text ? "Text & captions" : "Clip properties"}</h3>
      <details open>
        <summary>Timing</summary>
        {num("Start (seconds)", "start", 0, 86400)}
        {num(
          "Length (seconds)",
          "duration",
          0.04,
          m && c.kind !== "image" ? (m.duration - c.in) / c.speed : 86400,
        )}
        {m &&
          c.kind !== "image" &&
          num(
            "Source in (seconds)",
            "in",
            0,
            Math.max(0, m.duration - c.duration * c.speed),
          )}
        <label className="field">
          <span>Track</span>
          <select
            title="Move this clip to another track"
            value={c.track}
            onChange={(e) => set("track", +e.target.value)}
          >
            {p.tracks.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </label>
        {!text && c.kind !== "image" && (
          <>
            <label className="field">
              Speed
              <select
                title="Change playback speed and preserve the source range"
                value={c.speed}
                onChange={(e) => {
                  let speed = +e.target.value;
                  patch(c.id, {
                    speed,
                    duration: (c.duration * c.speed) / speed,
                  });
                }}
              >
                {[0.125, 0.25, 0.5, 1, 1.5, 2, 4, 8].map((v) => (
                  <option key={v} value={v}>
                    {v}×
                  </option>
                ))}
              </select>
            </label>
            {check("Reverse video and audio", "reverse")}
          </>
        )}
      </details>
      {text && (
        <details open>
          <summary>Title & caption style</summary>
          <textarea
            title="Edit caption or title text. Editing clears old word timing."
            value={c.text}
            onChange={(e) => patch(c.id, { text: e.target.value, words: [] })}
          />
          {choice("Preset", "style", [
            "minimal",
            "bold",
            "cinematic",
            "lower-third",
            "subtitle",
            "highlight",
            "karaoke",
            "boxed",
            "outlined",
          ])}
          <label className="field">
            Font
            <input
              title="Installed system font or bundled Noto family"
              list="fonts"
              value={c.font}
              onChange={(e) => set("font", e.target.value)}
            />
            <datalist id="fonts">
              {[
                "Noto Sans",
                "Noto Sans Arabic",
                "Noto Sans Devanagari",
                "Arial",
                "Segoe UI",
                "Georgia",
                "Consolas",
              ].map((f) => (
                <option key={f}>{f}</option>
              ))}
            </datalist>
          </label>
          {num("Font size (1080p)", "fontSize", 8, 300, 1)}
          {choice("Alignment", "align", ["left", "center", "right"])}
          {choice("Animation", "animation", [
            "none",
            "fade",
            "pop",
            "slide",
            "typewriter",
          ])}
          {["color", "highlight"].map((k) => (
            <label className="field" key={k}>
              {k}
              <input
                title={k}
                type="color"
                value={c[k as "color"]}
                onChange={(e) => set(k as "color", e.target.value)}
              />
            </label>
          ))}
          {slider("Outline", "outline", 0, 12, 0.5)}
          {slider("Shadow", "shadow", 0, 15, 0.5)}
          {check("Background box", "box")}
          {c.kind === "caption" && (
            <small>
              Highlight uses auto-caption word times. Editing words clears
              these; regenerate captions to realign.
            </small>
          )}
        </details>
      )}
      <details open>
        <summary>Position & motion</summary>
        {slider("Horizontal position", "x", 0, 1)}
        {slider("Vertical position", "y", 0, 1)}
        {slider("Scale", "scale", 0.1, 3)}
        {slider("Opacity", "opacity", 0, 1)}
        {slider("Rotate", "rotate", -180, 180, 1)}
        {!text && (
          <>
            {slider("Crop all edges", "crop", 0, 0.45)}
            {check("Flip horizontally", "flip")}
          </>
        )}
        <div className="key-controls">
          {(["x", "y", "scale", "opacity"] as const).map((key) => (
            <div key={key}>
              <button
                title={`Add or replace ${key} keyframe at the playhead using the current slider value`}
                onClick={() => {
                  const t = Math.max(0, Math.min(c.duration, time - c.start));
                  patch(c.id, {
                    keys: {
                      ...c.keys,
                      [key]: [
                        ...c.keys[key].filter((k) => Math.abs(k.t - t) > 0.001),
                        { t, value: c[key] },
                      ].sort((a, b) => a.t - b.t),
                    },
                  });
                }}
              >
                ◆ {key} ({c.keys[key].length})
              </button>
              <button
                title={`Clear ${key} keyframes`}
                onClick={() => patch(c.id, { keys: { ...c.keys, [key]: [] } })}
              >
                ×
              </button>
            </div>
          ))}
        </div>
        <small>
          Set a slider, move the playhead, then add a diamond. Values
          interpolate between diamonds.
        </small>
      </details>
      {!text && c.kind !== "audio" && (
        <>
          <details>
            <summary>Effects & colour</summary>
            {slider("Brightness", "brightness", -0.5, 0.5)}
            {slider("Contrast", "contrast", 0.2, 2)}
            {slider("Saturation", "saturation", 0, 3)}
            {slider("Temperature", "temperature", -1, 1)}
            {slider("Gaussian blur", "blur", 0, 30, 0.5)}
            {check("Blur background", "backgroundBlur")}
            {slider("Vignette", "vignette", 0, 1)}
            {slider("Sharpen", "sharpen", 0, 2)}
            {check("Black & white", "grayscale")}
            {slider("Glitch", "glitch", 0, 1)}
            {slider("Slow zoom", "zoom", 0, 1)}
            {slider("Shake", "shake", 0, 1)}
          </details>
          <details>
            <summary>Transitions</summary>
            {choice("Entrance / exit", "transition", [
              "none",
              "fade",
              "dissolve",
              "slide",
              "zoom",
              "wipe",
            ])}
            {num(
              "Transition seconds",
              "transitionDuration",
              0.05,
              c.duration / 2,
            )}
            <small>
              Overlap clips on different tracks for transitions between shots.
              Fade/dissolve fade at both ends; slide/zoom/wipe enter only.
            </small>
          </details>
          <details>
            <summary>Hide a face or private text</summary>
            <label className="check">
              <input
                type="checkbox"
                title="Enable privacy box"
                checked={c.mask.enabled}
                onChange={(e) =>
                  set("mask", { ...c.mask, enabled: e.target.checked })
                }
              />
              Enable privacy box
            </label>
            <select
              title="Privacy method"
              value={c.mask.mode}
              onChange={(e) => set("mask", { ...c.mask, mode: e.target.value })}
            >
              <option>blur</option>
              <option>mosaic</option>
            </select>
            {(["x", "y", "w", "h"] as const).map((k) => (
              <label className="slider" key={k}>
                {k}
                <input
                  type="range"
                  title={"Box " + k}
                  min="0.01"
                  max={k === "x" ? 1 - c.mask.w : k === "y" ? 1 - c.mask.h : 1}
                  step="0.01"
                  value={c.mask[k]}
                  onChange={(e) => {
                    let mask = { ...c.mask, [k]: +e.target.value };
                    mask.x = Math.min(mask.x, 1 - mask.w);
                    mask.y = Math.min(mask.y, 1 - mask.h);
                    set("mask", mask);
                  }}
                />
              </label>
            ))}
            <small>
              Click the preview to move the box. This is a static box, not
              automatic face tracking.
            </small>
          </details>
        </>
      )}
      {!text && (
        <details open>
          <summary>Audio</summary>
          {slider("Volume", "volume", 0, 2)}
          {check("Mute this clip", "mute")}
          {num("Fade in (seconds)", "fadeIn", 0, c.duration)}
          {num("Fade out (seconds)", "fadeOut", 0, c.duration)}
          {check("Reduce steady noise", "noise")}
          {check("Normalize loudness", "normalize")}
          <small>
            Noise reduction, normalization and reverse audio are heard in
            Rendered Preview.
          </small>
        </details>
      )}
    </aside>
  );
}
