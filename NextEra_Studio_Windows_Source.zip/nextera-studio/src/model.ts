export type Kind = "video" | "audio" | "image" | "title" | "caption";
export type Media = {
  id: string;
  path: string;
  name: string;
  kind: Kind;
  duration: number;
  width: number;
  height: number;
  hasAudio: boolean;
  waveform: number[];
  proxy?: string;
};
export type Key = { t: number; value: number };
export type Clip = {
  id: string;
  mediaId?: string;
  kind: Kind;
  track: number;
  start: number;
  duration: number;
  in: number;
  speed: number;
  reverse: boolean;
  text: string;
  words: { start: number; end: number; word: string }[];
  style: string;
  font: string;
  fontSize: number;
  color: string;
  highlight: string;
  outline: number;
  shadow: number;
  box: boolean;
  align: string;
  animation: string;
  x: number;
  y: number;
  scale: number;
  rotate: number;
  opacity: number;
  flip: boolean;
  crop: number;
  brightness: number;
  contrast: number;
  saturation: number;
  temperature: number;
  blur: number;
  backgroundBlur: boolean;
  vignette: number;
  sharpen: number;
  grayscale: boolean;
  glitch: number;
  zoom: number;
  shake: number;
  mask: {
    enabled: boolean;
    mode: string;
    x: number;
    y: number;
    w: number;
    h: number;
  };
  transition: string;
  transitionDuration: number;
  volume: number;
  mute: boolean;
  fadeIn: number;
  fadeOut: number;
  noise: boolean;
  normalize: boolean;
  keys: { x: Key[]; y: Key[]; scale: Key[]; opacity: Key[] };
};
export type Project = {
  version: 1;
  name: string;
  aspect: string;
  fps: number;
  tracks: { id: number; name: string }[];
  media: Media[];
  clips: Clip[];
};
export const uid = () => crypto.randomUUID();
export const empty = (): Project => ({
  version: 1,
  name: "My first movie",
  aspect: "16:9",
  fps: 30,
  tracks: [
    { id: 0, name: "Video 1" },
    { id: 1, name: "Video 2 / Titles" },
    { id: 2, name: "Music / Voice" },
  ],
  media: [],
  clips: [],
});
export const newClip = (kind: Kind, track: number, start: number): Clip => ({
  id: uid(),
  kind,
  track,
  start,
  duration: 5,
  in: 0,
  speed: 1,
  reverse: false,
  text: "Your story starts here",
  words: [],
  style: "minimal",
  font: "Noto Sans",
  fontSize: 60,
  color: "#ffffff",
  highlight: "#ffe65c",
  outline: 2,
  shadow: 2,
  box: false,
  align: "center",
  animation: "fade",
  x: 0.5,
  y: kind === "caption" ? 0.85 : 0.5,
  scale: 1,
  rotate: 0,
  opacity: 1,
  flip: false,
  crop: 0,
  brightness: 0,
  contrast: 1,
  saturation: 1,
  temperature: 0,
  blur: 0,
  backgroundBlur: false,
  vignette: 0,
  sharpen: 0,
  grayscale: false,
  glitch: 0,
  zoom: 0,
  shake: 0,
  mask: { enabled: false, mode: "blur", x: 0.3, y: 0.3, w: 0.25, h: 0.2 },
  transition: "none",
  transitionDuration: 0.5,
  volume: 1,
  mute: false,
  fadeIn: 0,
  fadeOut: 0,
  noise: false,
  normalize: false,
  keys: { x: [], y: [], scale: [], opacity: [] },
});
export const length = (p: Project) =>
  Math.max(0.1, ...p.clips.map((c) => c.start + c.duration));
export function valueAt(
  c: Clip,
  key: "x" | "y" | "scale" | "opacity",
  t: number,
) {
  const a = [...c.keys[key]].sort((a, b) => a.t - b.t);
  if (!a.length) return c[key];
  if (t <= a[0].t) return a[0].value;
  for (let i = 1; i < a.length; i++)
    if (t <= a[i].t) {
      let f = (t - a[i - 1].t) / (a[i].t - a[i - 1].t);
      return a[i - 1].value + (a[i].value - a[i - 1].value) * f;
    }
  return a[a.length - 1].value;
}
export function sliceClip(c: Clip, offset: number, duration: number): Clip {
  const words = c.words
    .filter((w) => w.end > offset && w.start < offset + duration)
    .map((w) => ({
      ...w,
      start: Math.max(0, w.start - offset),
      end: Math.min(duration, w.end - offset),
    }));
  return {
    ...structuredClone(c),
    start: c.start + offset,
    duration,
    in: Math.max(
      0,
      c.in + (c.reverse ? c.duration - offset - duration : offset) * c.speed,
    ),
    words,
    text:
      c.kind === "caption" && c.words.length
        ? words.map((w) => w.word).join(" ")
        : c.text,
    keys: Object.fromEntries(
      Object.entries(c.keys).map(([k, keys]) => [
        k,
        keys.length
          ? [
              { t: 0, value: valueAt(c, k as "x", offset) },
              ...keys
                .filter((v) => v.t > offset && v.t < offset + duration)
                .map((v) => ({ t: v.t - offset, value: v.value })),
              { t: duration, value: valueAt(c, k as "x", offset + duration) },
            ]
          : [],
      ]),
    ) as Clip["keys"],
  };
}
export function splitClip(c: Clip, t: number): Clip[] {
  const d = t - c.start;
  if (d <= 0.02 || d >= c.duration - 0.02) return [c];
  return [
    { ...sliceClip(c, 0, d), id: uid() },
    { ...sliceClip(c, d, c.duration - d), id: uid() },
  ];
}
