import { Clip, newClip } from "./model";
const seconds = (s: string) => {
  let [h, m, v] = s.replace(",", ".").split(":").map(Number);
  return h * 3600 + m * 60 + v;
};
const stamp = (n: number) => {
  let x = Math.round(Math.max(0, n) * 1000);
  return `${String(Math.floor(x / 3600000)).padStart(2, "0")}:${String(Math.floor(x / 60000) % 60).padStart(2, "0")}:${String(Math.floor(x / 1000) % 60).padStart(2, "0")},${String(x % 1000).padStart(3, "0")}`;
};
export function readSrt(text: string, track: number): Clip[] {
  return text
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .flatMap((block) => {
      let lines = block.split("\n"),
        i = lines.findIndex((l) => l.includes("-->"));
      if (i < 0) return [];
      let match = lines[i].match(
        /(\d+:\d+:\d+[,.]\d+)\s*-->\s*(\d+:\d+:\d+[,.]\d+)/,
      );
      if (!match) return [];
      let a = seconds(match[1]),
        b = seconds(match[2]);
      if (!Number.isFinite(a) || b <= a) return [];
      return [
        {
          ...newClip("caption", track, a),
          duration: b - a,
          text: lines.slice(i + 1).join("\n"),
          animation: "none",
        },
      ];
    });
}
export function writeSrt(clips: Clip[]) {
  return clips
    .filter((c) => c.kind === "caption")
    .sort((a, b) => a.start - b.start)
    .map(
      (c, i) =>
        `${i + 1}\n${stamp(c.start)} --> ${stamp(c.start + c.duration)}\n${c.text}\n`,
    )
    .join("\n");
}
