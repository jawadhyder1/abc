# NextEra Studio — local Windows video editor

An original Electron + React + TypeScript editor with Zustand, local JSON projects,
FFmpeg rendering and faster-whisper captions. Original source code is MIT licensed.
No accounts, cloud APIs, payments, subscriptions, telemetry or export watermark.

**Status: experimental v0.1 source project, not a production-ready Filmora replacement.**
The complete implementation is included; the build and automated export tests were
run. Windows installation, GPU drivers, microphone permissions and long editing
sessions have not been verified on an actual Windows laptop. See TEST_RESULTS.md
and LIMITATIONS.md before relying on it for an important project.

There is a licensing conflict in the requested specification: FFmpeg is LGPL/GPL,
not permissively licensed. The default downloaded build includes GPL libx264.
Google's Noto fonts are SIL OFL. These are free, open-source components, but they
cannot honestly be described as MIT/BSD/Apache-only. See THIRD_PARTY.md.

## Beginner Windows setup — no coding required

Use Windows 10/11 **64-bit x64**. This package does not target Windows ARM64.
Start with a short 1080p video and the tiny/base caption model. 16 GB RAM is a
practical starting point; complex 4K timelines and medium models need more memory.
Allow several GB of free disk space for dependencies, models and temporary renders.
There is no claim that 4K or multiple reverse clips will run smoothly on every laptop.

### 1. Extract the project

1. Right-click the downloaded ZIP and choose **Extract All**.
2. Move the extracted `nextera-studio` folder to `C:\NextEraStudio`.
3. Open that folder. You should see `Setup.cmd`, `Start.cmd`, `package.json`,
   and the `src`, `electron`, `backend` and `scripts` folders directly inside it.
4. Do not run scripts from inside the ZIP.

### 2. Install Node.js

1. Open https://nodejs.org/en/download.
2. Choose **Node.js 24 LTS**, **Windows**, **x64**, **Windows Installer (.msi)**.
3. Run the installer and accept the normal defaults. npm is included.
4. Close old Command Prompt windows after installation.

### 3. Install Python

1. Open https://www.python.org/downloads/release/python-31210/.
2. Under Files, choose **Windows installer (64-bit)**, not the embeddable package.
3. Run it. Check **Add python.exe to PATH** and keep the Python launcher enabled.
4. Click **Install Now**. Python 3.11 is also supported by the setup script.

This is a fixed compatible interpreter baseline, not a promise that 3.12.10 is the
newest Python release. Newer major interpreters have not been tested with this
package's pinned speech dependencies.

### 4. Run first-time setup

Double-click **Setup.cmd**. Keep the window open until it says **Setup complete**.
It installs JavaScript and Python dependencies, downloads a Windows FFmpeg build,
and builds the interface. Noto Sans, Noto Sans Arabic and Noto Sans Devanagari fonts
and their licenses are already included; setup can retrieve missing copies.

This step needs internet. Editing and transcription do not need internet afterwards.
Dependency downloads are free. No sign-in or API key is required.

If you prefer exact commands, open the folder, click the File Explorer address bar,
type `cmd`, press Enter, and paste:

```bat
node --version
py -3.12 --version
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\setup.ps1
```

The execution-policy option applies only to this script invocation. You do not need
to change your computer's global execution policy or disable security software.

### 5. Install a caption model once

Double-click **Download-Base-Model.cmd**. Wait for it to finish.

For another model, run one of these commands from the project folder:

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download-model.ps1 tiny
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download-model.ps1 base
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download-model.ps1 small
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\download-model.ps1 medium
```

You only need the models you plan to use. Tiny is quickest but less accurate; small
and medium take longer and use more memory. The multilingual models are used, not
English-only `.en` models. Downloads are stored in `resources\models\MODEL`.
Restart the editor after adding a model.

### 6. Start the editor

Double-click **Start.cmd**, or run:

```bat
npm start
```

After setup and your model download, disconnect the internet and try editing.
The running editor does not download models or use an online transcription service.
If a model is missing, it explains how to install it instead of silently going online.

### 7. Make your first video

1. Click **Import media** and pick a short video. Or drag a file into the window.
2. Drag its media card onto **Video 1**, or double-click it to add at the playhead.
3. Click the timeline ruler to move the playhead. Press **Space** to play/pause.
4. Select a clip, move the playhead, and press **S** to split it. Select an unwanted
   piece and press **Delete**. Drag the left/right handles to trim.
5. Open **Titles**, click a preset, and edit its text in the right-hand panel.
6. Open **Captions → Auto Captions**, choose an installed model and language, then
   click **Generate captions**. The audible timeline mix is transcribed, including
   background music: mute music first if it makes recognition less clear.
7. Select each caption and proofread it. Choose highlight, karaoke, boxed or outlined.
8. Click **Render preview** to inspect the actual export filters at low resolution.
9. Click **Save** to save the editable JSON project.
10. Click **Export MP4**, choose **1080p / 30 FPS / Recommended / Software H.264**,
    then **Choose file & export**. The resulting MP4 has no added watermark.

## Working with the editor

- **Tracks:** higher numbered video tracks appear above lower ones. Titles and
  captions are composited above all video tracks. Drag a clip to move it in time
  or onto another track; the Track selector also moves it between tracks.
- **Snapping:** toggle Snap near timeline controls. Clip starts snap to the playhead
  and other clip boundaries. Timeline zoom changes the pixels per second.
- **Speed/reverse:** select a clip → Timing. Reverse audio is available in rendered
  preview/export; fast preview uses frame seeking and mutes reverse audio.
- **Text:** five title templates, editable font, size, colour, outline, shadow,
  background, alignment, position, duration and fade/pop/slide/typewriter animation.
- **Fonts:** bundled Noto families work without internet. Type an installed system
  font name for another font; it must also be available to FFmpeg on this machine.
- **Effects:** select video → Effects & colour. Sliders include brightness, contrast,
  saturation, temperature, Gaussian/background blur, vignette, sharpen, grayscale,
  periodic RGB-shift glitch, slow zoom and procedural shake.
- **Transform:** position, scale, rotation, opacity, horizontal flip, symmetrical
  crop. Position/scale/opacity support linear keyframes. Set a slider, place the
  playhead inside the clip and click the relevant diamond. Add another at a later
  time. The adjacent × clears the channel's keyframes.
- **Transitions:** overlap two shots on different tracks. Select the upper clip,
  choose fade/dissolve/slide/zoom/wipe, set its transition duration. Fade and
  dissolve fade both ends; the other choices are entrance effects.
- **Privacy:** enable a blur/mosaic box, then adjust its rectangle or click in the
  preview to move its centre. Render and inspect the result before sharing a video
  that contains private information. There is no automatic face tracking.
- **Audio:** import audio onto any track, or click Voice to record from the microphone.
  Click Stop when finished. The recording is added at the playhead's original time.
  Windows microphone permission must be enabled. Volume, fades, mute, stationary
  noise reduction and single-pass loudness normalization are available per clip.
- **SRT:** Captions → Import .srt / Export .srt. SRT preserves text and timing, not
  word timing, styling or animation. Changing an auto caption's text intentionally
  clears old word timing. Regenerate captions to realign words.
- **Roman Urdu:** select Urdu + Roman Urdu approximation. This uses a small common-word
  dictionary and character transliteration. It is not a trained Roman Urdu language
  model; Urdu's omitted vowels make automatic transliteration ambiguous. Proofread.
- **Proxies:** enable Low-res preview. The editor creates 640-pixel H.264 proxies.
  Originals are always used for rendering and transcription. Cache stays local.
- **Save/open:** JSON stores absolute source paths, not media bytes. Keep originals
  in place. For transfer to another PC, move your media and update paths in the JSON,
  or reimport and rebuild the affected clips. Automatic relinking is not implemented.
- **Recovery:** edits are autosaved after 1.5 seconds of inactivity. Projects → Recover
  autosave restores the last snapshot. The initial empty screen does not overwrite
  recovery. Save manually before changing projects and before closing the app.
- **Frame step:** left/right arrows or preview controls. Compressed-source seeking in
  fast preview is approximate; exported frames follow the selected project FPS.

## Build the Windows EXE installer

Do this **on Windows**, after setup. The ZIP contains source, not a prebuilt Windows
EXE. You do not need to write or modify any code.

1. Download all caption models you want available in your installed app.
2. Double-click **Build-Installer.cmd**.
3. Wait for Python worker bundling and the Electron installer build.
4. Open the new **release** folder.
5. Run **NextEra Studio Setup 0.1.0.exe**.

Equivalent commands:

```bat
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\build-worker.ps1
npm run dist
```

The installer bundles the Electron runtime, FFmpeg/ffprobe, fonts, any installed
models, and the frozen Python caption/render worker. The installed app does not
need Node.js or a separate Python installation. Models can make it very large.
There is no paid signing certificate; an unsigned installer may trigger Windows
reputation warnings. Inspect your own build rather than disabling security checks.

To add models to an installed build, download them in the source folder and rebuild
its installer. The source version is easier for experimenting with models.

## Manual FFmpeg setup if automatic download fails

1. Visit https://github.com/BtbN/FFmpeg-Builds/releases/tag/latest.
2. Download **ffmpeg-master-latest-win64-gpl.zip** (x64, GPL, non-shared).
3. Extract it. Open its `bin` folder.
4. Copy **ffmpeg.exe** and **ffprobe.exe** into `resources\bin` in this project.
5. Retain the build's license/source information with your local copy.
6. Run Setup.cmd again. It will use the binaries already present.

You need a build with libx264, libass/subtitles, gblur and the standard audio filters.
No system-wide PATH change is needed for normal editor use.

## Test commands

From Command Prompt in this folder:

```bat
set PATH=%CD%\resources\bin;%PATH%
node --experimental-strip-types --test tests\editor.test.mjs
.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run build
npm run test:ui
```

The UI test opens a separate temporary-profile editor, adds a title, and checks its
properties. The export tests generate their own test video/audio and render real
MP4s. Caption inference integration is opt-in; see TEST_RESULTS.md.

## Troubleshooting

| What happened | What to do |
|---|---|
| `node` or `npm` not recognized | Reinstall Node.js LTS with default PATH settings; close and reopen the terminal. |
| Python was not found | Install Python 3.11/3.12 x64 with the launcher; verify `py -3.12 --version`. |
| Download fails | Keep the source folder outside OneDrive/protected folders; check internet/proxy. Retry setup. Use manual FFmpeg steps if needed. |
| No installed caption models | Run Download-Base-Model.cmd, wait until complete, then restart the app. |
| Captions are slow | Use tiny/base, short clips and CPU int8. GPU caption inference is not implemented. |
| Font is missing | Use a bundled Noto family. For Urdu choose Noto Sans Arabic; Hindi: Noto Sans Devanagari. |
| Black or unplayable fast preview | Enable Low-res preview to create an H.264 proxy, or use Render preview. Some source codecs are not supported by Chromium. |
| Effects/audio differ in fast preview | Use Render preview; browser effects are approximations and audio DSP runs in FFmpeg. |
| Hardware export failed | Choose Software H.264. An encoder probe cannot guarantee every project works with every driver. |
| Export uses a lot of memory | Reduce resolution/clip overlap. Reverse filters buffer the selected source segment. Split long reversed sections. |
| Source file missing | Put the file back at its original path. The JSON project does not embed source media. |
| Microphone fails | Windows Settings → Privacy & security → Microphone; allow desktop apps. Verify the default input device. |
| App closed unexpectedly | Reopen → Projects → Recover autosave. Temporary exports use `.partial.mp4`; completed files are replaced only on success. |
| Installer cannot build | Build on Windows x64. Run Setup.cmd first, then Build-Installer.cmd. Keep the full error text. |

Cache, autosave and voice recordings live under Electron's user-data directory,
normally `%APPDATA%\nextera-studio` during source runs (the packaged name may differ).
Do not delete the recordings folder: projects can refer to it. You can delete the
cache folder while the editor is closed; remove obsolete proxy paths from projects
or regenerate proxies if you do. Cancelled jobs may leave temporary partial files.

## Architecture and source map

The sandboxed renderer has no Node access. A narrow preload bridge exposes import,
save, local file URLs and named worker operations. The main process owns dialogs,
allowlisted file streaming, autosave, subprocess lifetime and encoder detection.
The Python worker consumes one JSON request from stdin and writes progress/result
JSON lines to stdout. FFmpeg is invoked with argument arrays and no shell.

Zustand keeps immutable project snapshots with up to 80 undo states. Canvas composes
HTML5 media in the fast preview. FFmpeg compiles the timeline into per-clip trims,
transforms, alpha overlays, an audio mix and a generated ASS subtitle file. A separate
rendered-preview MP4 uses that same compiler. Temporary output is committed with an
atomic replace only after FFmpeg succeeds. Original source files are never modified.

| Location | Contents |
|---|---|
| `src/model.ts` | Typed media, clip, keyframe and project model; split logic |
| `src/store.ts` | Zustand project state, history and edit actions |
| `src/App.tsx` | Library, dialogs, captions, recording, projects and export UI |
| `src/Timeline.tsx` | Tracks, move/trim gestures, snapping, waveform and zoom |
| `src/Preview.tsx` | Canvas compositor, HTML5 source playback, rendered MP4 preview |
| `src/Properties.tsx` | Text, effects, audio, transforms and keyframes |
| `src/srt.ts` | SRT parsing and serialization |
| `src/api.ts` | Typed IPC bridge API |
| `src/main.tsx`, `src/style.css` | React entry point, error boundary, original dark design |
| `electron/main.cjs` | Window security, IPC, file IO, jobs and cancellation |
| `electron/preload.cjs` | Narrow context-isolated bridge |
| `backend/render.py` | FFmpeg filter compiler and ASS writer |
| `backend/worker.py` | Media probing, waveforms, proxies, captions, encoder probes |
| `backend/requirements.txt` | Python requirements |
| `scripts/` | Setup, explicit model download and frozen-worker build |
| `tests/` | Export integration, timeline unit, optional caption and UI smoke tests |
| `resources/fonts/` | Three bundled Google Noto fonts |
| `resources/licenses/` | Noto OFL notices; setup adds FFmpeg download provenance |
| `resources/bin/` | Setup places Windows FFmpeg/ffprobe here |
| `resources/models/` | Explicit setup places local Whisper models here |
| `resources/worker/` | Windows build places the frozen Python worker here |
| `package.json`, `package-lock.json` | npm scripts, pinned dependency resolution, installer configuration |
| `tsconfig.json`, `vite.config.ts`, `index.html` | TypeScript, frontend build and CSP |
| `LICENSE`, `THIRD_PARTY.md` | Original-code license and component licensing notes |
| `LIMITATIONS.md`, `TEST_RESULTS.md` | Honest scope and validation status |

No proprietary Filmora code, graphics, template assets or branding are used.
