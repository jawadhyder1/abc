# Third-party software and licensing

Original NextEra Studio source: MIT (LICENSE).

| Component | Upstream license / notes |
|---|---|
| Electron | MIT; Chromium/Node and bundled components retain their own notices. https://github.com/electron/electron |
| React, React DOM | MIT. https://github.com/facebook/react |
| Zustand | MIT. https://github.com/pmndrs/zustand |
| TypeScript | Apache-2.0. https://github.com/microsoft/TypeScript |
| Vite | MIT. https://github.com/vitejs/vite |
| electron-builder | MIT; packaging toolchain components retain their licenses. https://github.com/electron-userland/electron-builder |
| faster-whisper | MIT. https://github.com/SYSTRAN/faster-whisper |
| CTranslate2 | MIT. https://github.com/OpenNMT/CTranslate2 |
| Hugging Face Hub | Apache-2.0. https://github.com/huggingface/huggingface_hub |
| Whisper weights | Original OpenAI Whisper weights/code MIT; converted Systran model artifacts and model cards should be retained with downloaded copies. https://github.com/openai/whisper |
| Noto fonts | SIL Open Font License 1.1. Notices bundled under resources/licenses. https://github.com/google/fonts |
| Python | PSF license; transitive Python wheels include further notices. https://docs.python.org/3/license.html |
| PyInstaller | GPL with special exception permitting distribution of bundled applications under their own licenses. Build-time tool, not a relicensing of original application source. https://pyinstaller.org/en/stable/license.html |
| FFmpeg | LGPL by default; default setup selects BtbN's GPL build including libx264. https://ffmpeg.org/legal.html |
| libx264 | GPL in this free build. https://www.videolan.org/developers/x264.html |
| PyAV | BSD source wrapper, with bundled FFmpeg libraries retaining their LGPL/GPL licenses. https://github.com/PyAV-Org/PyAV |

The request for FFmpeg and exclusively permissive licenses cannot be satisfied
simultaneously. This project uses free open-source licensing exceptions, disclosed
above. It does not use a paid encoder license, cloud service or proprietary Filmora
assets. H.264 patent questions are distinct from source-code licenses.

Do not remove upstream notices. If distributing a compiled installer to other
people, retain the exact FFmpeg source/build configuration and fulfill applicable
source-distribution obligations for that build. A general upstream URL alone is
not a complete redistribution-compliance package. Setup records the binary URL,
release and SHA-256 but does not itself assemble all corresponding FFmpeg sources.
The provided installer scripts are intended first for your own personal local build.

Direct dependency versions are in package-lock.json and backend/requirements.txt.
Python transitive dependency versions are resolved by pip; they are not a complete
cross-platform hash lock. Recheck notices in the installed dependency packages when
upgrading or redistributing. No assertion is made that every transitive dependency
in the bundled binary is permissively licensed.
