$ErrorActionPreference = 'Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
Write-Host 'NextEra Studio - first-time setup (internet required)' -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Install Node.js LTS from https://nodejs.org then reopen Setup.cmd.' }
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw 'Install Python 3.11 or 3.12 (64 bit) from https://python.org. Enable the Python launcher.' }
if (-not (Test-Path '.venv\Scripts\python.exe')) {
  & py -3.11 -m venv .venv
  if ($LASTEXITCODE -ne 0) { & py -3.12 -m venv .venv }
  if ($LASTEXITCODE -ne 0) { throw 'Python 3.11 or 3.12 is required. Install one and run setup again.' }
}
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw 'Could not update pip. Check your internet connection.' }
& .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed.' }
& npm.cmd ci --no-audit --no-fund
if ($LASTEXITCODE -ne 0) { throw 'Node dependency installation failed.' }
New-Item -ItemType Directory -Force resources\bin, resources\fonts, resources\models, resources\licenses | Out-Null
if (-not (Test-Path 'resources\bin\ffmpeg.exe')) {
  Write-Host 'Downloading free FFmpeg GPL build (includes H.264 software encoder)...'
  $headers = @{ 'User-Agent' = 'NextEra-Studio-Setup' }
  $release = Invoke-RestMethod 'https://api.github.com/repos/BtbN/FFmpeg-Builds/releases/tags/latest' -Headers $headers
  $asset = $release.assets | Where-Object { $_.name -eq 'ffmpeg-master-latest-win64-gpl.zip' } | Select-Object -First 1
  if (-not $asset) { throw 'FFmpeg download name changed. See README manual FFmpeg setup.' }
  $zipPath = Join-Path $env:TEMP ('nextera-ffmpeg-' + [guid]::NewGuid().ToString() + '.zip')
  $extractPath = $zipPath + '-unpacked'
  Invoke-WebRequest $asset.browser_download_url -OutFile $zipPath
  $actual = (Get-FileHash $zipPath -Algorithm SHA256).Hash.ToLower()
  if ($asset.digest -and $asset.digest.StartsWith('sha256:')) {
    if ($actual -ne $asset.digest.Substring(7).ToLower()) { Remove-Item $zipPath; throw 'FFmpeg integrity check failed.' }
  }
  Expand-Archive $zipPath -DestinationPath $extractPath
  Get-ChildItem $extractPath -Recurse -Filter '*.exe' | Where-Object { $_.Name -in @('ffmpeg.exe','ffprobe.exe') } | Copy-Item -Destination resources\bin
  @{ url=$asset.browser_download_url; sha256=$actual; release=$release.html_url; date=(Get-Date).ToString('o'); source='https://github.com/BtbN/FFmpeg-Builds'; license='GPL build - see upstream' } | ConvertTo-Json | Set-Content resources\licenses\ffmpeg-download.json
  Get-ChildItem $extractPath -Recurse -File | Where-Object { $_.Name -match '^(LICENSE|COPYING)' } | Copy-Item -Destination resources\licenses -Force
  Remove-Item $zipPath
  Remove-Item $extractPath -Recurse -Force
}
$fonts = @(
  @{dir='notosans'; file='NotoSans[wdth,wght].ttf'; name='NotoSans.ttf'},
  @{dir='notosansarabic'; file='NotoSansArabic[wdth,wght].ttf'; name='NotoSansArabic.ttf'},
  @{dir='notosansdevanagari'; file='NotoSansDevanagari[wdth,wght].ttf'; name='NotoSansDevanagari.ttf'}
)
foreach ($font in $fonts) {
  if (-not (Test-Path ('resources\fonts\'+$font.name))) {
    $url='https://raw.githubusercontent.com/google/fonts/main/ofl/'+$font.dir+'/'+[uri]::EscapeDataString($font.file)
    Invoke-WebRequest $url -OutFile ('resources\fonts\'+$font.name)
    Invoke-WebRequest ('https://raw.githubusercontent.com/google/fonts/main/ofl/'+$font.dir+'/OFL.txt') -OutFile ('resources\licenses\'+$font.dir+'-OFL.txt')
  }
}
& .\resources\bin\ffmpeg.exe -version | Select-Object -First 3
& npm.cmd run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed. Copy the error text when requesting help.' }
Write-Host 'Setup complete. Now double-click Start.cmd. For captions, double-click Download-Base-Model.cmd once.' -ForegroundColor Green
