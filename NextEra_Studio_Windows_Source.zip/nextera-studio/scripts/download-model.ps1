param([ValidateSet('tiny','base','small','medium')][string]$Model='base')
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'Run Setup.cmd first.' }
& .\.venv\Scripts\python.exe scripts\download_model.py $Model
if ($LASTEXITCODE -ne 0) { throw 'Model download failed. Check your connection and retry.' }
Write-Host 'Model installed. Restart the editor. Offline captions are now available.' -ForegroundColor Green
