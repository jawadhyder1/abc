$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
if (-not (Test-Path 'resources\bin\ffmpeg.exe')) { throw 'Run Setup.cmd before building.' }
& .\.venv\Scripts\python.exe -m pip install 'pyinstaller==6.16.0'
if ($LASTEXITCODE -ne 0) { throw 'PyInstaller installation failed.' }
& .\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean --onedir --name nextera-worker --paths backend --collect-all faster_whisper --collect-all ctranslate2 --collect-all tokenizers --collect-all av --collect-all onnxruntime --collect-all huggingface_hub --copy-metadata faster-whisper --distpath .worker-build backend\worker.py
if ($LASTEXITCODE -ne 0) { throw 'Worker build failed.' }
New-Item -ItemType Directory -Force resources\worker | Out-Null
Copy-Item .worker-build\nextera-worker\* resources\worker -Recurse -Force
Write-Host 'Python runtime bundled. Run npm run dist to create the Windows installer.' -ForegroundColor Green
