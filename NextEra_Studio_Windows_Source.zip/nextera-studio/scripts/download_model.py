"""Explicit online setup only. Runtime transcription never downloads models."""
import argparse,json
from pathlib import Path
from huggingface_hub import snapshot_download
p=argparse.ArgumentParser();p.add_argument('model',choices=['tiny','base','small','medium']);a=p.parse_args()
root=Path(__file__).resolve().parents[1];dest=root/'resources'/'models'/a.model
snapshot_download('Systran/faster-whisper-'+a.model,local_dir=dest,allow_patterns=['*.json','*.bin','*.txt','README.md','LICENSE*'])
if not (dest/'model.bin').exists():raise SystemExit('Download incomplete; model.bin is missing.')
print('Installed',a.model,'at',dest)
