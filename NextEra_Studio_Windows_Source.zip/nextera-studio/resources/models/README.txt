Run scripts/download-model.ps1 tiny, base, small or medium once while online.
Each model has its own subfolder. Runtime reads only local models.
Installed models are included when you build the Windows installer.
