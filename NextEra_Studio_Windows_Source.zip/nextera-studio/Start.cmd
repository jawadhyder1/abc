@echo off
cd /d "%~dp0"
if not exist node_modules\electron\dist\electron.exe (
 echo Please run Setup.cmd first.
 pause
 exit /b 1
)
call npm start
if errorlevel 1 pause
