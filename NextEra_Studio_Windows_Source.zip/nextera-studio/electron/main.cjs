const {
  app,
  BrowserWindow,
  ipcMain,
  dialog,
  protocol,
  net,
  session,
} = require("electron");
const fs = require("node:fs/promises"),
  fss = require("node:fs"),
  path = require("node:path"),
  { spawn } = require("node:child_process"),
  { pathToFileURL } = require("node:url"),
  crypto = require("node:crypto");
protocol.registerSchemesAsPrivileged([
  {
    scheme: "media",
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      stream: true,
    },
  },
]);
let win,
  current = null,
  allowed = new Set(),
  jobs = new Map();
const root = app.isPackaged
  ? process.resourcesPath
  : path.join(__dirname, "..");
const resources = path.join(root, "resources");
const user = () => app.getPath("userData"),
  cache = () => path.join(user(), "cache");
const grant = (p) => {
  allowed.add(path.resolve(p));
  return p;
};
const exists = (p) => fss.existsSync(p);
async function atomic(file, text) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = file + "." + crypto.randomUUID() + ".tmp";
  await fs.writeFile(temp, text, "utf8");
  await fs.rename(temp, file);
}
function worker(op, data, id = crypto.randomUUID()) {
  return new Promise((resolve, reject) => {
    const frozen = path.join(resources, "worker", "nextera-worker.exe");
    const py = path.join(
      root,
      ".venv",
      process.platform === "win32" ? "Scripts" : "bin",
      process.platform === "win32" ? "python.exe" : "python",
    );
    const cmd = exists(frozen)
      ? frozen
      : exists(py)
        ? py
        : process.platform === "win32"
          ? "python"
          : "python3";
    const child = spawn(
      cmd,
      exists(frozen) ? [] : [path.join(root, "backend", "worker.py")],
      {
        windowsHide: true,
        detached: process.platform !== "win32",
        env: {
          ...process.env,
          PYTHONIOENCODING: "utf-8",
          HF_HUB_OFFLINE: "1",
          TRANSFORMERS_OFFLINE: "1",
        },
      },
    );
    jobs.set(id, child);
    let line = "",
      stderr = "",
      result,
      error;
    child.stdout.on("data", (buf) => {
      line += buf.toString();
      let at;
      while ((at = line.indexOf("\n")) >= 0) {
        const raw = line.slice(0, at);
        line = line.slice(at + 1);
        try {
          const msg = JSON.parse(raw);
          if ("progress" in msg)
            win?.webContents.send("progress", { id, ...msg });
          if ("result" in msg) result = msg.result;
          if (msg.error) error = msg.error;
        } catch {}
      }
    });
    child.stderr.on("data", (b) => {
      stderr = (stderr + b.toString()).slice(-5000);
    });
    child.on("error", (e) => {
      jobs.delete(id);
      reject(
        new Error(
          "Cannot start local worker. Run Setup.cmd first. " + e.message,
        ),
      );
    });
    child.on("close", (code) => {
      jobs.delete(id);
      if (code !== 0 || error)
        reject(new Error(error || "Operation stopped. " + stderr));
      else resolve(result);
    });
    child.stdin.on("error", () => {});
    child.stdin.end(JSON.stringify({ op, data, resources, cache: cache() }));
  });
}
function kill(id) {
  const child = jobs.get(id);
  if (!child) return;
  if (process.platform === "win32")
    spawn("taskkill", ["/PID", String(child.pid), "/T", "/F"], {
      windowsHide: true,
    });
  else
    try {
      process.kill(-child.pid, "SIGTERM");
    } catch {}
  jobs.delete(id);
}
async function recent() {
  try {
    return JSON.parse(
      await fs.readFile(path.join(user(), "recent.json"), "utf8"),
    );
  } catch {
    return [];
  }
}
async function remember(file) {
  await atomic(
    path.join(user(), "recent.json"),
    JSON.stringify(
      [file, ...(await recent()).filter((p) => p !== file)].slice(0, 12),
    ),
  );
}
function projectSafe(p) {
  if (
    !p ||
    p.version !== 1 ||
    !Array.isArray(p.media) ||
    !Array.isArray(p.clips) ||
    !Array.isArray(p.tracks)
  )
    throw Error("Not a NextEra Studio v1 project.");
  for (const m of p.media) {
    if (typeof m.path !== "string") throw Error("Invalid media path");
    grant(m.path);
    if (m.proxy) grant(m.proxy);
  }
  return p;
}
async function importPaths(paths) {
  let out = [];
  for (const file of paths) {
    grant(file);
    out.push(await worker("probe", { path: file }));
  }
  return out;
}
function handle(name, fn) {
  ipcMain.handle(name, async (event, ...args) => {
    if (
      event.sender !== win.webContents ||
      event.senderFrame !== win.webContents.mainFrame
    )
      throw Error("Untrusted request");
    return fn(...args);
  });
}
app.whenReady().then(async () => {
  await fs.mkdir(cache(), { recursive: true });
  for (const name of await fs
    .readdir(path.join(resources, "fonts"))
    .catch(() => []))
    grant(path.join(resources, "fonts", name));
  protocol.handle("media", async (request) => {
    let p = new URL(request.url).searchParams.get("path");
    if (!p || !allowed.has(path.resolve(p)))
      return new Response("Access denied", { status: 403 });
    const response = await net.fetch(pathToFileURL(p).href, {
      headers: request.headers,
    });
    const headers = new Headers(response.headers);
    headers.set("Access-Control-Allow-Origin", "*");
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
  });
  session.defaultSession.setPermissionRequestHandler(
    (wc, permission, callback) =>
      callback(wc === win?.webContents && permission === "media"),
  );
  handle("import", async (paths) => {
    if (!paths) {
      let r = await dialog.showOpenDialog(win, {
        properties: ["openFile", "multiSelections"],
        filters: [
          {
            name: "Media",
            extensions: [
              "mp4",
              "mkv",
              "mov",
              "webm",
              "avi",
              "mp3",
              "wav",
              "m4a",
              "flac",
              "ogg",
              "png",
              "jpg",
              "jpeg",
              "webp",
              "bmp",
            ],
          },
        ],
      });
      if (r.canceled) return [];
      paths = r.filePaths;
    }
    return importPaths(paths);
  });
  handle("save", async (p, as) => {
    projectSafe(p);
    let dest = current;
    if (!dest || as) {
      let r = await dialog.showSaveDialog(win, {
        defaultPath: p.name + ".json",
        filters: [{ name: "NextEra project", extensions: ["json"] }],
      });
      if (r.canceled) return null;
      dest = r.filePath;
    }
    await atomic(dest, JSON.stringify(p, null, 2));
    current = dest;
    await remember(dest);
    return dest;
  });
  handle("open", async (file) => {
    if (file && !(await recent()).includes(file))
      throw Error("Choose the project with Open.");
    if (!file) {
      let r = await dialog.showOpenDialog(win, {
        filters: [{ name: "NextEra project", extensions: ["json"] }],
      });
      if (r.canceled) return null;
      file = r.filePaths[0];
    }
    let p = projectSafe(JSON.parse(await fs.readFile(file, "utf8")));
    await worker("validate", { project: p });
    current = file;
    await remember(file);
    return p;
  });
  handle("recent", recent);
  handle("new-project", () => {
    current = null;
  });
  let autosaveChain = Promise.resolve();
  handle("autosave", (p) => {
    projectSafe(p);
    autosaveChain = autosaveChain
      .catch(() => {})
      .then(() =>
        atomic(path.join(user(), "recovery.json"), JSON.stringify(p)),
      );
    return autosaveChain;
  });
  handle("recover", async () => {
    try {
      const p = projectSafe(
        JSON.parse(
          await fs.readFile(path.join(user(), "recovery.json"), "utf8"),
        ),
      );
      current = null;
      return p;
    } catch {
      return null;
    }
  });
  handle("fonts", async () =>
    ["NotoSans.ttf", "NotoSansArabic.ttf", "NotoSansDevanagari.ttf"]
      .map((name) => path.join(resources, "fonts", name))
      .filter(exists),
  );
  handle("models", async () => {
    let result = [];
    for (const size of ["tiny", "base", "small", "medium"])
      if (exists(path.join(resources, "models", size, "model.bin")))
        result.push(size);
    return result;
  });
  handle("job", async (id, op, data) => {
    if (!["export", "preview", "captions", "proxy", "encoders"].includes(op))
      throw Error("Unsupported task");
    if (data.project) projectSafe(data.project);
    if (op === "proxy" && !allowed.has(path.resolve(data.path)))
      throw Error("Import this media first.");
    if (op === "export") {
      let r = await dialog.showSaveDialog(win, {
        defaultPath: (data.project.name || "movie") + ".mp4",
        filters: [{ name: "MP4 video", extensions: ["mp4"] }],
      });
      if (r.canceled) return null;
      if (
        data.project.media.some(
          (m) =>
            path.resolve(m.path).toLowerCase() ===
            path.resolve(r.filePath).toLowerCase(),
        )
      )
        throw Error(
          "Choose a new filename. Export cannot replace source media.",
        );
      data = { ...data, output: r.filePath };
    }
    if (op === "preview")
      data = {
        ...data,
        output: path.join(cache(), "preview-" + crypto.randomUUID() + ".mp4"),
      };
    let result = await worker(op, data, id);
    if (op === "preview" || op === "proxy") grant(result);
    return result;
  });
  handle("cancel", kill);
  handle("read-srt", async () => {
    let r = await dialog.showOpenDialog(win, {
      filters: [{ name: "Subtitles", extensions: ["srt"] }],
    });
    return r.canceled ? null : fs.readFile(r.filePaths[0], "utf8");
  });
  handle("write-srt", async (text) => {
    let r = await dialog.showSaveDialog(win, { defaultPath: "captions.srt" });
    if (!r.canceled) await atomic(r.filePath, text);
  });
  handle("record", async (bytes) => {
    let dir = path.join(user(), "recordings");
    await fs.mkdir(dir, { recursive: true });
    let file = path.join(dir, "Voice-" + Date.now() + ".webm");
    await fs.writeFile(file, Buffer.from(bytes));
    return (await importPaths([file]))[0];
  });
  win = new BrowserWindow({
    width: 1500,
    height: 960,
    minWidth: 1050,
    minHeight: 720,
    backgroundColor: "#101116",
    title: "NextEra Studio",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  win.webContents.on("will-navigate", (e) => e.preventDefault());
  win.webContents.on("render-process-gone", () =>
    dialog.showErrorBox(
      "Editor stopped",
      "Your latest autosave can be restored with Recover autosave after restarting.",
    ),
  );
  await win.loadFile(path.join(root, "dist", "index.html"));
});
app.on("window-all-closed", () => {
  for (const id of jobs.keys()) kill(id);
  app.quit();
});
