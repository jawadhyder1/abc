const { contextBridge, ipcRenderer, webUtils } = require("electron");
const invoke = (name, ...args) => ipcRenderer.invoke(name, ...args);
contextBridge.exposeInMainWorld("studio", {
  paths: (files) => files.map((f) => webUtils.getPathForFile(f)),
  url: (p) => "media://local/?path=" + encodeURIComponent(p),
  importMedia: (p) => invoke("import", p),
  save: (p, as) => invoke("save", p, as),
  open: (p) => invoke("open", p),
  recent: () => invoke("recent"),
  autosave: (p) => invoke("autosave", p),
  recover: () => invoke("recover"),
  job: (id, op, data) => invoke("job", id, op, data),
  cancel: (id) => invoke("cancel", id),
  onProgress: (fn) => {
    const cb = (_, p) => fn(p);
    ipcRenderer.on("progress", cb);
    return () => ipcRenderer.removeListener("progress", cb);
  },
  readSrt: () => invoke("read-srt"),
  writeSrt: (t) => invoke("write-srt", t),
  record: (b) => invoke("record", b),
  models: () => invoke("models"),
  fonts: () => invoke("fonts"),
  newProject: () => invoke("new-project"),
});
