"""Deterministic FFmpeg filter compiler. No shell commands or cloud services."""
import json, math, os, re, subprocess, tempfile
from pathlib import Path


def number(value, default=0):
    try:
        v=float(value)
        return v if math.isfinite(v) else default
    except (ValueError,TypeError): return default


def validate(p):
    if not isinstance(p,dict) or p.get('version')!=1: raise ValueError('Unsupported project. Open a version 1 NextEra JSON project.')
    if not isinstance(p.get('clips'),list) or not isinstance(p.get('media'),list): raise ValueError('Project is missing media or clips.')
    ids=set()
    for m in p['media']:
        if m['id'] in ids: raise ValueError('Duplicate media ID.')
        ids.add(m['id'])
        if not Path(m['path']).is_file(): raise ValueError('Media moved or missing: '+m['path']+'. Restore it to its original folder.')
    for c in p['clips']:
        for k in ['start','duration','in','speed']:
            if not isinstance(c.get(k),(int,float)) or not math.isfinite(c[k]): raise ValueError('Invalid clip '+k)
        if c['start']<0 or c['duration']<=0 or c['in']<0 or not .125<=c['speed']<=8: raise ValueError('Invalid timing or speed.')
        if c['kind'] not in ['title','caption'] and c.get('mediaId') not in ids: raise ValueError('A clip has no source media.')
    if len(p['clips'])>2000: raise ValueError('Please split this project into smaller projects (2,000 clip limit).')
    return p


def duration(p): return max([.1]+[c['start']+c['duration'] for c in p['clips']])


def dimensions(aspect,res):
    a,b=map(int,aspect.split(':'))
    if (a,b) not in [(16,9),(9,16),(1,1),(4,5)]: raise ValueError('Unsupported aspect ratio')
    h=int(res);w=round(h*a/b/2)*2
    # Portrait presets use the short edge, matching the landscape pixel count.
    if a<b: w=int(res);h=round(w*b/a/2)*2
    return w,h


def expr(c,key,var='t'):
    keys=sorted(c.get('keys',{}).get(key,[]),key=lambda x:x['t'])
    if not keys:return str(number(c.get(key),1 if key in ['scale','opacity'] else .5))
    out=str(number(keys[-1]['value']))
    for a,b in reversed(list(zip(keys,keys[1:]))):
        dt=max(.0001,b['t']-a['t'])
        linear=f"({number(a['value'])}+({number(b['value'])}-{number(a['value'])})*({var}-{number(a['t'])})/{dt})"
        out=f"if(lt({var},{number(b['t'])}),{linear},{out})"
    return f"if(lt({var},{number(keys[0]['t'])}),{number(keys[0]['value'])},{out})"


def atempo(speed):
    out=[]
    while speed>2:out.append('atempo=2');speed/=2
    while speed<.5:out.append('atempo=0.5');speed/=.5
    return out+[f'atempo={speed}']


def safe_text(s):return str(s).replace('\\','\\\\').replace('{','(').replace('}',')').replace('\n',r'\N').replace('\r','')
def ass_color(s):
    s=s if re.fullmatch('#[a-fA-F0-9]{6}',str(s)) else '#ffffff'
    return '&H'+s[5:7]+s[3:5]+s[1:3]+'&'
def ass_time(t):
    n=round(max(0,t)*100);return f'{n//360000}:{n//6000%60:02}:{n//100%60:02}.{n%100:02}'


def write_ass(p,path,w,h):
    lines=['[Script Info]','ScriptType: v4.00+',f'PlayResX: {w}',f'PlayResY: {h}','ScaledBorderAndShadow: yes','WrapStyle: 0','[V4+ Styles]','Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding','Style: Default,Noto Sans,60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2,2,5,20,20,20,1','[Events]','Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
    def event(c,a,b,text,tags):
        lines.append(f"Dialogue: {int(c.get('track',0))},{ass_time(a)},{ass_time(b)},Default,,0,0,0,,{{{tags}}}{text}")
    for c in sorted(p['clips'],key=lambda c:c['track']):
        if c['kind'] not in ['title','caption']:continue
        d=c['duration'];a=c['start'];size=number(c.get('fontSize'),60)*h/1080
        font=re.sub(r'[{},\\\r\n]','',str(c.get('font','Noto Sans')))
        align={'left':4,'center':5,'right':6}.get(c.get('align'),5)
        x=number(c.get('x'),.5)*w;y=number(c.get('y'),.85)*h
        tags=fr'\an{align}\fn{font}\fs{size:.2f}\1c{ass_color(c.get("color"))}\3c&H000000&\bord{number(c.get("outline"),2)}\shad{number(c.get("shadow"),2)}\frz{-number(c.get("rotate"))}\fscx{number(c.get("scale"),1)*100}\fscy{number(c.get("scale"),1)*100}\alpha&H{round((1-max(0,min(1,number(c.get("opacity"),1))))*255):02X}&'
        tags+=fr'\pos({x:.2f},{y:.2f})'
        if c.get('box') or c.get('style')=='boxed':tags+=r'\bord8\shad0\3a&H40&\3c&H151515&\be1'
        # BorderStyle=3 requires an override style; use opaque-box reset style per clip.
        if c.get('box') or c.get('style')=='boxed':
            style='Box'+str(len(lines));idx=lines.index('[Events]')
            lines.insert(idx,'Style: '+style+',Noto Sans,60,&H00FFFFFF,&H00FFFFFF,&H00151515,&H80151515,0,0,0,0,100,100,0,0,3,8,0,5,20,20,20,1')
            tags=fr'\r{style}'+tags
        if c.get('style') in ['bold','cinematic']:tags+=r'\b1'
        anim=c.get('animation');ms=min(300,int(d*500))
        if anim=='fade':tags+=fr'\fad({ms},{ms})'
        if anim=='pop':tags+=fr'\fscx65\fscy65\t(0,{ms},\fscx100\fscy100)'
        if anim=='slide':tags=tags.replace(fr'\pos({x:.2f},{y:.2f})',fr'\move({x-w*.2:.2f},{y:.2f},{x:.2f},{y:.2f},0,{ms})')
        # Keyframes use ASS transforms. Position uses sampled events below for exact linear movement.
        text=safe_text(c.get('text',''))
        words=c.get('words',[])
        if words and c.get('style')=='highlight':
            points=sorted(set([0,d]+[max(0,min(d,wrd[k])) for wrd in words for k in ['start','end']]))
            for begin,end in zip(points,points[1:]):
                styled=' '.join(fr'{{\1c{ass_color(c.get("highlight","#ffe65c") if wrd["start"]<=begin<wrd["end"] else c.get("color","#ffffff"))}}}'+safe_text(wrd['word']) for wrd in words)
                event(c,a+begin,a+end,styled,tags)
            continue
        if words and c.get('style') in ['highlight','karaoke']:
            text='';cursor=0
            for word in words:
                gap=max(0,word['start']-cursor)
                if gap:text+=fr'{{\k{round(gap*100)}}}'
                k='kf' if c['style']=='karaoke' else 'k'
                text+=fr'{{\{k}{max(1,round((word["end"]-word["start"])*100))}}}'+safe_text(word['word'])+' '
                cursor=word['end']
            tags+=fr'\1c{ass_color(c.get("highlight","#ffe65c"))}\2c{ass_color(c.get("color","#ffffff"))}'
        if any(c.get('keys',{}).get(k) for k in ['x','y','scale','opacity']):
            fps=p.get('fps',30)
            for n in range(math.ceil(d*fps)):
                t=n/fps;end=min(d,(n+1)/fps)
                def val(k):
                    keys=sorted(c.get('keys',{}).get(k,[]),key=lambda x:x['t'])
                    if not keys:return number(c.get(k),1)
                    if t<=keys[0]['t']:return keys[0]['value']
                    for ka,kb in zip(keys,keys[1:]):
                        if t<=kb['t']:return ka['value']+(kb['value']-ka['value'])*(t-ka['t'])/max(.0001,kb['t']-ka['t'])
                    return keys[-1]['value']
                kt=re.sub(r'\\pos\([^)]*\)',fr'\\pos({val("x")*w:.2f},{val("y")*h:.2f})',tags)
                kt+=fr'\fscx{val("scale")*100}\fscy{val("scale")*100}\alpha&H{round((1-max(0,min(1,val("opacity"))))*255):02X}&'
                event(c,a+t,a+end,text,kt)
        elif anim=='typewriter':
            raw=c.get('text','');period=min(1.5,d*.6)
            for i in range(1,len(raw)+1):event(c,a+(i-1)*period/max(1,len(raw)),a+i*period/max(1,len(raw)) if i<len(raw) else a+d,safe_text(raw[:i]),tags)
        else:event(c,a,a+d,text,tags)
    Path(path).write_text('\n'.join(lines),encoding='utf-8-sig')


def filter_path(path):return str(Path(path).resolve()).replace('\\','/').replace(':',r'\:').replace("'",r"\'")


def compile_graph(p,settings,work,ffmpeg='ffmpeg',audio_only=False,fonts=None):
    validate(p);total=duration(p);res=settings.get('resolution',1080);w,h=dimensions(p.get('aspect','16:9'),res);fps=int(settings.get('fps',p.get('fps',30)))
    if fps not in [24,25,30,50,60]:raise ValueError('Choose 24, 25, 30, 50 or 60 FPS.')
    media={m['id']:m for m in p['media']};args=[ffmpeg,'-hide_banner','-y','-filter_complex_threads','1'];graph=[];inputs={};index=0
    used=[c for c in sorted(p['clips'],key=lambda c:(c['track'],c['start'])) if c['kind'] not in ['title','caption']]
    for c in used:
        m=media[c['mediaId']]
        if audio_only and not m.get('hasAudio'):continue
        if c['kind']=='image':args+=['-loop','1','-framerate',str(fps)]
        args+=['-i',m['path']];inputs[c['id']]=index;index+=1
    graph.append(f'anullsrc=r=48000:cl=stereo,atrim=duration={total}[silence]');audio=['[silence]']
    if not audio_only:graph.append(f'color=c=black:s={w}x{h}:r={fps}:d={total},format=rgba[base]')
    base='base';serial=0
    for c in used:
        if c['id'] not in inputs:continue
        i=inputs[c['id']];m=media[c['mediaId']];d=c['duration'];start=c['start'];speed=c['speed'];srcdur=d*speed;serial+=1;tag=f'c{serial}'
        if m.get('hasAudio') and not c.get('mute'):
            f=[f'atrim=start={c["in"]}:duration={srcdur}','asetpts=PTS-STARTPTS']
            if c.get('reverse'):f+=['areverse']
            f+=atempo(speed)
            if c.get('noise'):f+=['afftdn=nf=-25']
            if c.get('normalize'):f+=['loudnorm=I=-16:TP=-1.5:LRA=11']
            f+=[f'volume={max(0,number(c.get("volume"),1))}']
            if c.get('fadeIn',0)>0:f+=[f'afade=t=in:d={min(d,c["fadeIn"])}']
            if c.get('fadeOut',0)>0:f+=[f'afade=t=out:st={max(0,d-c["fadeOut"])}:d={min(d,c["fadeOut"])}']
            f+=['aformat=sample_rates=48000:channel_layouts=stereo',f'adelay={round(start*1000)}:all=1',f'apad=whole_dur={total}',f'atrim=duration={total}']
            graph.append(f'[{i}:a]'+','.join(f)+f'[{tag}a]');audio.append(f'[{tag}a]')
        if audio_only or c['kind']=='audio':continue
        f=[f'trim=start={c["in"] if c["kind"]!="image" else 0}:duration={srcdur}','setpts=PTS-STARTPTS']
        if c.get('reverse'):f+=['reverse']
        f+=[f'setpts=PTS/{speed}',f'fps={fps}','setsar=1']
        crop=max(0,min(.45,number(c.get('crop'))))
        if crop:f+=[f'crop=iw*{1-2*crop}:ih*{1-2*crop}']
        graph.append(f'[{i}:v]'+','.join(f)+f'[{tag}source]')
        src=tag+'source'
        if c.get('backgroundBlur'):
            graph.append(f'[{src}]split[{tag}frontsrc][{tag}backsrc]');src=tag+'frontsrc'
            graph.append(f'[{tag}backsrc]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},gblur=sigma=30,format=rgba[{tag}bgb]')
        graph.append(f'[{src}]scale={w}:{h}:force_original_aspect_ratio=decrease,format=rgba,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black@0[{tag}fit]');cur=tag+'fit'
        if c.get('backgroundBlur'):
            graph.append(f'[{tag}bgb][{cur}]overlay=shortest=1:format=auto[{tag}filled]');cur=tag+'filled'
        graph.append(f'[{cur}]split[{tag}rgb][{tag}alphaSource]')
        graph.append(f'[{tag}alphaSource]alphaextract[{tag}alpha]');cur=tag+'rgb'
        f=[f'eq=brightness={number(c.get("brightness"))}:contrast={number(c.get("contrast"),1)}:saturation={0 if c.get("grayscale") else number(c.get("saturation"),1)}']
        temp=number(c.get('temperature'))*.3
        if temp:f+=[f'colorbalance=rs={temp}:bs={-temp}']
        if c.get('blur',0)>0:f+=[f'gblur=sigma={c["blur"]}']
        if c.get('sharpen',0)>0:f+=[f'unsharp=5:5:{c["sharpen"]}:5:5:0']
        if c.get('vignette',0)>0:f+=[f'vignette=angle={c["vignette"]}*PI/4']
        if c.get('glitch',0)>0:f+=[f"rgbashift=rh={round(c['glitch']*12)}:bh={-round(c['glitch']*12)}:enable='lt(mod(t,0.8),0.12)'"]
        if c.get('flip'):f+=['hflip']
        f+=['format=rgba'];graph.append(f'[{cur}]'+','.join(f)+f'[{tag}color]');graph.append(f'[{tag}color][{tag}alpha]alphamerge[{tag}fx]');cur=tag+'fx'
        mask=c.get('mask',{})
        if mask.get('enabled'):
            mx=round(max(0,min(.95,mask.get('x',.3)))*w/2)*2;my=round(max(0,min(.95,mask.get('y',.3)))*h/2)*2
            mw=max(2,min(w-mx,round(mask.get('w',.25)*w/2)*2));mh=max(2,min(h-my,round(mask.get('h',.2)*h/2)*2))
            graph.append(f'[{cur}]split[{tag}clean][{tag}cut]')
            effect=f'scale={max(2,mw//20)}:{max(2,mh//20)},scale={mw}:{mh}:flags=neighbor' if mask.get('mode')=='mosaic' else 'gblur=sigma=20'
            graph.append(f'[{tag}cut]crop={mw}:{mh}:{mx}:{my},{effect}[{tag}mask]')
            graph.append(f'[{tag}clean][{tag}mask]overlay={mx}:{my}:shortest=1:format=auto[{tag}masked]');cur=tag+'masked'
        transition=c.get('transition','none');td=max(.01,min(d/2,number(c.get('transitionDuration'),.5)))
        scale=f'({expr(c,"scale")})*(1+{number(c.get("zoom"))}*t/{d})'
        if transition=='zoom':scale+=f'*min(1,0.5+t/{td}*0.5)'
        f=[f"scale=w='max(2,trunc({w}*({scale})/2)*2)':h='max(2,trunc({h}*({scale})/2)*2)':eval=frame"]
        if c.get('rotate',0):f+=[f'rotate={c["rotate"]}*PI/180:ow=rotw({c["rotate"]}*PI/180):oh=roth({c["rotate"]}*PI/180):c=none']
        f+=['format=rgba']
        if c.get('keys',{}).get('opacity'):
            f+=[f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*({expr(c,'opacity','T')})'"]
        else:f+=[f'colorchannelmixer=aa={max(0,min(1,number(c.get("opacity"),1)))}']
        if transition in ['fade','dissolve']:f+=[f'fade=t=in:st=0:d={td}:alpha=1',f'fade=t=out:st={d-td}:d={td}:alpha=1']
        if transition=='wipe':f+=[f"geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':a='alpha(X,Y)*lte(X,W*min(1,T/{td}))'"]
        f+=[f'setpts=PTS+{start}/TB'];graph.append(f'[{cur}]'+','.join(f)+f'[{tag}ready]')
        local=f'(t-{start})';x=f'{w}*({expr(c,"x",local)})-overlay_w/2';y=f'{h}*({expr(c,"y",local)})-overlay_h/2'
        if transition=='slide':x+=f'-{w}*max(0,1-{local}/{td})'
        if c.get('shake',0):
            x+=f'+{c["shake"]*w*.015}*sin({local}*43)';y+=f'+{c["shake"]*h*.015}*cos({local}*37)'
        out=f'layer{serial}';graph.append(f"[{base}][{tag}ready]overlay=x='{x}':y='{y}':eof_action=pass:repeatlast=0:format=auto:enable='gte(t,{start})*lt(t,{start+d})'[{out}]");base=out
    graph.append(''.join(audio)+f'amix=inputs={len(audio)}:duration=longest:normalize=0,alimiter=limit=0.97:latency=1,atrim=duration={total}[aout]')
    if not audio_only:
        ass=Path(work)/'titles.ass';write_ass(p,ass,w,h)
        sub=f"subtitles=filename='{filter_path(ass)}'"
        if fonts:sub+=f":fontsdir='{filter_path(fonts)}'"
        graph.append(f'[{base}]'+sub+',format=yuv420p[vout]')
    script=Path(work)/'filters.txt';script.write_text(';\n'.join(graph),encoding='utf-8')
    args+=['-filter_complex_script',str(script)]
    if audio_only:args+=['-map','[aout]','-c:a','pcm_s16le','-ar','16000','-ac','1']
    else:
        encoder=settings.get('encoder','libx264')
        if encoder not in ['libx264','h264_nvenc','h264_qsv','h264_amf']:raise ValueError('Unsupported encoder')
        quality=int(settings.get('quality',20))
        args+=['-map','[vout]','-map','[aout]','-c:v',encoder]
        if encoder=='libx264':args+=['-preset','veryfast','-crf',str(quality)]
        elif encoder=='h264_nvenc':args+=['-cq',str(quality),'-b:v','0']
        elif encoder=='h264_qsv':args+=['-global_quality',str(quality)]
        else:args+=['-rc','cqp','-qp_i',str(quality),'-qp_p',str(quality)]
        args+=['-c:a','aac','-b:a','192k','-movflags','+faststart','-r',str(fps)]
    args+=['-t',str(total),'-progress','pipe:1','-nostats']
    return args,total


def run_render(p,settings,output,ffmpeg='ffmpeg',fonts=None,progress=lambda n,m:None,audio_only=False):
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True)
    # Existing destination survives failed/cancelled exports. Work is staged next to it.
    with tempfile.TemporaryDirectory(prefix='nextera-') as work:
        args,total=compile_graph(p,settings,work,ffmpeg,audio_only,fonts)
        partial=output.with_name(output.stem+'.partial'+output.suffix)
        log=Path(work)/'ffmpeg.log'
        try:
            with log.open('w',encoding='utf-8') as err:
                proc=subprocess.Popen(args+[str(partial)],stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',errors='replace')
                for line in proc.stdout:
                    if line.startswith('out_time_us='):
                        try:progress(min(.99,int(line.split('=')[1])/1e6/total),'Rendering locally')
                        except ValueError:pass
                proc.stdout.close()
                code=proc.wait()
            if code:raise RuntimeError('FFmpeg export failed. Try Software H.264, or check your media.\n'+log.read_text(encoding='utf-8')[-5000:])
            os.replace(partial,output);progress(1,'Done');return str(output)
        finally:
            if partial.exists():partial.unlink()
