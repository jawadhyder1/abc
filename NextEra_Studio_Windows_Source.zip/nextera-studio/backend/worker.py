import json, os, sys, subprocess, tempfile, hashlib, re
from pathlib import Path
from render import run_render, duration, validate


def emit(data):print(json.dumps(data,ensure_ascii=False),flush=True)
def progress(n,m):emit({'progress':n,'message':m})
def command(args):
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if result.returncode:raise RuntimeError(result.stderr.decode('utf8','replace')[-4000:])
    return result.stdout


def probe(path,ffprobe,ffmpeg,cache):
    data=json.loads(command([ffprobe,'-v','error','-show_streams','-show_format','-of','json',path]))
    streams=data.get('streams',[]);video=next((s for s in streams if s['codec_type']=='video'),None);audio=any(s['codec_type']=='audio' for s in streams)
    image=Path(path).suffix.lower() in ['.jpg','.jpeg','.png','.webp','.bmp']
    if not video and not audio:raise ValueError('This file has no playable video or audio: '+path)
    d=float(data.get('format',{}).get('duration',video.get('duration',5) if video else 5));wave=[]
    if audio:
        # Bounded waveform: downsample to 8kHz, then reduce to 400 peaks.
        raw=command([ffmpeg,'-v','error','-i',path,'-vn','-ac','1','-ar','8000','-f','s16le','-'])
        import array
        samples=array.array('h',raw);step=max(1,len(samples)//400)
        wave=[round(max((abs(x) for x in samples[i:i+step]),default=0)/32768,4) for i in range(0,len(samples),step)]
    return {'id':hashlib.sha256((path+str(Path(path).stat().st_mtime_ns)).encode()).hexdigest()[:24],'path':path,'name':Path(path).name,'kind':'image' if image else 'video' if video else 'audio','duration':5 if image else d,'width':video.get('width',0) if video else 0,'height':video.get('height',0) if video else 0,'hasAudio':audio,'waveform':wave}

ROMAN_WORDS={'میں':'main','ہے':'hai','ہیں':'hain','آپ':'aap','یہ':'yeh','وہ':'woh','اور':'aur','کی':'ki','کے':'ke','کا':'ka','کو':'ko','سے':'se','نہیں':'nahin','کیا':'kya','کر':'kar','ایک':'ek','ہم':'hum','ہو':'ho','پر':'par','بھی':'bhi','تو':'to','لیے':'liye','اس':'is','کے':'ke','مجھے':'mujhe','تم':'tum','آج':'aaj','شکریہ':'shukriya'}
ROMAN_LETTERS={'ا':'a','آ':'aa','ب':'b','پ':'p','ت':'t','ٹ':'t','ث':'s','ج':'j','چ':'ch','ح':'h','خ':'kh','د':'d','ڈ':'d','ذ':'z','ر':'r','ڑ':'r','ز':'z','ژ':'zh','س':'s','ش':'sh','ص':'s','ض':'z','ط':'t','ظ':'z','ع':'a','غ':'gh','ف':'f','ق':'q','ک':'k','ك':'k','گ':'g','ل':'l','م':'m','ن':'n','ں':'n','و':'o','ہ':'h','ھ':'h','ء':"'",'ی':'i','ي':'i','ے':'e','ؤ':'o','ئ':'i','،':',','۔':'.','؟':'?','َ':'a','ِ':'i','ُ':'u','ّ':'','ْ':''}
def romanize(text):return re.sub(r'[\u0600-\u06ff]+',lambda m:ROMAN_WORDS.get(m[0],''.join(ROMAN_LETTERS.get(ch,ch) for ch in m[0])),text)


def captions(data,ffmpeg,resources,cache):
    from faster_whisper import WhisperModel
    p=validate(data['project']);size=data.get('model','base')
    if size not in ['tiny','base','small','medium']:raise ValueError('Choose tiny, base, small or medium.')
    modelpath=resources/'models'/size
    if not (modelpath/'model.bin').exists():raise ValueError('Model not installed: '+size+'. Run scripts/download-model.ps1 '+size+' once while online, then restart.')
    with tempfile.TemporaryDirectory(prefix='captions-') as work:
        wav=str(Path(work)/'mix.wav')
        run_render(p,{'resolution':720,'fps':30},wav,ffmpeg,progress=lambda n,m:progress(n*.2,'Preparing timeline audio'),audio_only=True)
        progress(.22,'Loading offline '+size+' model')
        model=WhisperModel(str(modelpath),device='cpu',compute_type='int8',local_files_only=True)
        language=data.get('language','auto')
        segments,info=model.transcribe(wav,language=None if language=='auto' else language,word_timestamps=True,vad_filter=True)
        result=[]
        for seg in segments:
            words=[{'start':w.start,'end':w.end,'word':romanize(w.word.strip()) if data.get('roman') else w.word.strip()} for w in seg.words or []]
            # Short four-word captions, retaining exact word timing relative to each caption.
            for i in range(0,len(words),4):
                group=words[i:i+4];a=group[0]['start'];b=group[-1]['end']
                if b<=a:continue
                result.append({'start':a,'duration':b-a,'text':' '.join(w['word'] for w in group),'words':[dict(w,start=w['start']-a,end=w['end']-a) for w in group]})
            progress(.25+.74*seg.end/max(1,duration(p)),'Transcribing on your CPU')
        return result


def main():
    req=json.load(sys.stdin);data=req.get('data',{});resources=Path(req['resources']);cache=Path(req['cache']);cache.mkdir(parents=True,exist_ok=True)
    suffix='.exe' if os.name=='nt' else '';ffmpeg=str(resources/'bin'/('ffmpeg'+suffix));ffprobe=str(resources/'bin'/('ffprobe'+suffix))
    if not Path(ffmpeg).exists():ffmpeg='ffmpeg';ffprobe='ffprobe'
    op=req['op']
    if op=='probe':result=probe(data['path'],ffprobe,ffmpeg,cache)
    elif op=='validate':result=validate(data['project'])
    elif op=='export' or op=='preview':
        settings=data.get('settings',{})
        if op=='preview':settings={**settings,'resolution':360,'encoder':'libx264','quality':25}
        result=run_render(data['project'],settings,data['output'],ffmpeg,resources/'fonts',progress)
    elif op=='captions':result=captions(data,ffmpeg,resources,cache)
    elif op=='proxy':
        src=data['path'];name=hashlib.sha256((src+str(Path(src).stat().st_mtime_ns)).encode()).hexdigest()+'.mp4';out=cache/name
        if not out.exists():command([ffmpeg,'-v','error','-y','-i',src,'-vf','scale=640:640:force_original_aspect_ratio=decrease:force_divisible_by=2','-c:v','libx264','-preset','ultrafast','-crf','28','-c:a','aac',str(out)])
        result=str(out)
    elif op=='encoders':
        result=['libx264']
        for enc in ['h264_nvenc','h264_qsv','h264_amf']:
            test=subprocess.run([ffmpeg,'-v','error','-f','lavfi','-i','color=s=128x128:d=0.1','-c:v',enc,'-f','null','-'],capture_output=True)
            if test.returncode==0:result.append(enc)
    else:raise ValueError('Unknown operation')
    emit({'result':result})

if __name__=='__main__':
    try:main()
    except Exception as e:emit({'error':str(e)});sys.exit(1)
