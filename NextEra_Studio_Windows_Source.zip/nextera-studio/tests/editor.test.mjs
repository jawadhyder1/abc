import { test } from "node:test";
import assert from "node:assert/strict";
import { newClip, splitClip, valueAt } from "../src/model.ts";
test("split conserves duration and source offsets at 2x", () => {
  const c = { ...newClip("video", 0, 3), duration: 4, in: 2, speed: 2 };
  const [a, b] = splitClip(c, 4.5);
  assert.equal(a.duration + b.duration, c.duration);
  assert.equal(b.in, 5);
  assert.equal(b.start, 4.5);
  assert.equal(a.in, 2);
});
test("reverse split preserves source playback order", () => {
  const c = { ...newClip("video", 0, 0), duration: 4, in: 2, reverse: true };
  const [a, b] = splitClip(c, 1);
  assert.equal(a.in, 5);
  assert.equal(b.in, 2);
  assert.equal(a.duration, 1);
  assert.equal(b.duration, 3);
});
test("split shifts caption word timing and interpolates keyframe boundary", () => {
  const c = {
    ...newClip("caption", 1, 0),
    duration: 2,
    words: [
      { start: 0, end: 1, word: "hello" },
      { start: 1, end: 2, word: "world" },
    ],
  };
  c.keys.x = [
    { t: 0, value: 0 },
    { t: 2, value: 1 },
  ];
  const [a, b] = splitClip(c, 1);
  assert.equal(a.words.length, 1);
  assert.equal(b.words[0].start, 0);
  assert.equal(valueAt(a, "x", 1), 0.5);
  assert.equal(valueAt(b, "x", 0), 0.5);
});
test("split on boundaries is a no-op", () => {
  let c = newClip("video", 0, 0);
  assert.deepEqual(splitClip(c, 0), [c]);
  assert.deepEqual(splitClip(c, 5), [c]);
});
test("split keeps unanimated channels unanimated and caption text agrees with words", () => {
  const c = {
    ...newClip("caption", 1, 0),
    duration: 2,
    words: [
      { start: 0, end: 1, word: "hello" },
      { start: 1, end: 2, word: "world" },
    ],
  };
  const [a, b] = splitClip(c, 1);
  assert.equal(a.text, "hello");
  assert.equal(b.text, "world");
  assert.deepEqual(a.keys.opacity, []);
});
