"""Opt-in real inference test. Never downloads anything during this test."""
import os,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from worker import captions,probe

@unittest.skipUnless(os.getenv('NEXTERA_TEST_SPEECH'), 'Set NEXTERA_TEST_SPEECH to a local English speech WAV and install tiny to run actual inference')
class CaptionIntegration(unittest.TestCase):
 def test_local_inference_word_timestamps(self):
  root=Path(__file__).resolve().parents[1];sample=str(Path(os.environ['NEXTERA_TEST_SPEECH']).resolve())
  with tempfile.TemporaryDirectory() as temp:
   m=probe(sample,'ffprobe','ffmpeg',Path(temp));p={'version':1,'aspect':'16:9','fps':30,'media':[m],'clips':[{'id':'voice','mediaId':m['id'],'kind':'audio','track':0,'start':0,'duration':m['duration'],'in':0,'speed':1}]}
   result=captions({'project':p,'model':'tiny','language':'en'},'ffmpeg',root/'resources',Path(temp))
   self.assertGreater(len(result),0)
   self.assertTrue(all(c['duration']>0 and c['words'] for c in result))
   for c in result:
    for w in c['words']:self.assertGreaterEqual(w['start'],0);self.assertGreaterEqual(w['end'],w['start']);self.assertLessEqual(w['end'],c['duration']+.001)
   expected=os.environ.get('NEXTERA_EXPECT_PHRASE')
   if expected:self.assertIn(expected.lower(),' '.join(c['text'] for c in result).lower())
   print('CAPTION TEXT:',' '.join(c['text'] for c in result))
