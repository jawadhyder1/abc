import json,sys,unittest,tempfile,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backend'))
from render import run_render,compile_graph,validate,dimensions,write_ass,atempo
from worker import romanize

class ExportTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):raise unittest.SkipTest('FFmpeg and ffprobe required on PATH')
  cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name);cls.video=cls.root/'source with spaces.mp4'
  subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i','color=c=red:s=160x90:r=30:d=2','-f','lavfi','-i','sine=frequency=440:duration=2','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(cls.video)],check=True)
 @classmethod
 def tearDownClass(cls):cls.temp.cleanup()
 def project(self):
  return {'version':1,'aspect':'16:9','fps':30,'media':[{'id':'a','path':str(self.video),'hasAudio':True}], 'clips':[{'id':'c','mediaId':'a','kind':'video','track':0,'start':.2,'duration':1.2,'in':.1,'speed':1,'x':.5,'y':.5,'scale':1,'opacity':1,'keys':{}}]}
 def probe(self,out):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out)]))
 def render(self,p,name='out.mp4'):
  out=self.root/name;run_render(p,{'resolution':180,'fps':30},str(out));return out
 def test_mp4_duration_resolution_audio_and_no_overwrite(self):
  out=self.render(self.project());d=self.probe(out);v=next(s for s in d['streams'] if s['codec_type']=='video')
  self.assertEqual((v['width'],v['height']),(320,180));self.assertTrue(any(s['codec_type']=='audio' for s in d['streams']));self.assertAlmostEqual(float(d['format']['duration']),1.4,delta=.1)
  original=out.read_bytes();bad=self.project();bad['media'][0]['path']='missing.mp4'
  with self.assertRaises(ValueError):run_render(bad,{'resolution':180,'fps':30},out)
  self.assertEqual(original,out.read_bytes())
 def test_real_pixels_gap_and_top_layer(self):
  p=self.project();out=self.render(p,'pixels.mp4')
  def pixel(t,x,y):
   raw=subprocess.check_output(['ffmpeg','-v','error','-ss',str(t),'-i',str(out),'-frames:v','1','-f','rawvideo','-pix_fmt','rgb24','-'])
   at=(y*320+x)*3;return tuple(raw[at:at+3])
  self.assertTrue(all(v<12 for v in pixel(.05,160,90)), 'Timeline gap must be black')
  red=pixel(.6,160,90);self.assertGreater(red[0],220);self.assertLess(red[1],25);self.assertLess(red[2],25)
  # No implicit branding or graphics: source-only solid red remains solid in the corners.
  self.assertGreater(pixel(.6,15,15)[0],220)
 def test_filters_titles_privacy_and_keyframes(self):
  p=self.project();c=p['clips'][0];c.update({'brightness':.05,'contrast':1.1,'saturation':.9,'temperature':.2,'blur':1,'sharpen':.3,'vignette':.3,'glitch':.4,'rotate':4,'flip':True,'transition':'fade','transitionDuration':.2,'mask':{'enabled':True,'mode':'mosaic','x':.2,'y':.2,'w':.3,'h':.3},'keys':{'scale':[{'t':0,'value':1},{'t':1,'value':.8}],'x':[{'t':0,'value':.4},{'t':1,'value':.6}],'opacity':[{'t':0,'value':.5},{'t':1,'value':1}]}})
  p['clips'].append({'id':'title','kind':'title','track':1,'start':0,'duration':1.4,'in':0,'speed':1,'text':"It's a test: {safe} \\ text",'animation':'typewriter','font':'DejaVu Sans','fontSize':64,'x':.5,'y':.5})
  out=self.render(p,'effects.mp4');self.assertGreater(out.stat().st_size,1000)
 def test_speed_reverse_audio_mix_transitions(self):
  for transition in ['slide','zoom','wipe','dissolve']:
   p=self.project();c=p['clips'][0];c.update({'speed':2,'duration':.8,'reverse':True,'transition':transition,'noise':True,'normalize':True,'fadeIn':.1,'fadeOut':.1,'backgroundBlur':True})
   p['clips'].append(dict(c,id='overlay',track=1,start=.4,opacity=.5,scale=.4,reverse=False))
   self.render(p,transition+'.mp4')
 def test_silent_titles_only_portrait_and_word_timing(self):
  p=self.project();p['media']=[];p['aspect']='9:16';p['clips']=[{'id':'t','kind':'caption','track':1,'start':0,'duration':1,'in':0,'speed':1,'text':'hello world','style':'karaoke','words':[{'start':0,'end':.5,'word':'hello'},{'start':.5,'end':1,'word':'world'}],'box':True,'keys':{'x':[{'t':0,'value':.2},{'t':1,'value':.8}]}}]
  out=self.render(p,'portrait.mp4');v=self.probe(out)['streams'][0];self.assertEqual((v['width'],v['height']),(180,320))
 def test_empty_timeline_and_audio_only(self):
  p=self.project();p['clips'][0]['kind']='audio';self.render(p,'audio-black.mp4');out=self.root/'mix.wav';run_render(p,{'resolution':180},out,audio_only=True);self.assertEqual(self.probe(out)['streams'][0]['sample_rate'],'16000')
 def test_validation_and_math(self):
  p=self.project();p['clips'][0]['speed']=0
  with self.assertRaises(ValueError):validate(p)
  self.assertEqual(dimensions('16:9',2160),(3840,2160));self.assertEqual(atempo(8),['atempo=2','atempo=2','atempo=2.0']);self.assertEqual(romanize('آپ کیسے ہیں'),'aap kise hain')

if __name__=='__main__':unittest.main()
