// Run on a GUI-capable machine: npx electron tests/electron-smoke.cjs
const { app, BrowserWindow } = require("electron");
const path = require("node:path"),
  fs = require("node:fs"),
  os = require("node:os");
const testData = fs.mkdtempSync(path.join(os.tmpdir(), "nextera-ui-test-"));
app.setPath("userData", testData);
require("../electron/main.cjs");
let errors = [];
app.on("browser-window-created", (_, win) => {
  win.webContents.on("console-message", (_event, level, message) => {
    if (level === 3 && !message.includes("Autofill")) errors.push(message);
  });
  win.webContents.on("did-finish-load", async () => {
    try {
      await new Promise((r) => setTimeout(r, 1500));
      const result = await win.webContents.executeJavaScript(`(async()=>{
    const text=document.body.innerText;
    if(!text.includes('NextEra')||!text.includes('Timeline'))throw Error('Editor did not render');
    [...document.querySelectorAll('button')].find(b=>b.textContent==='Titles').click();
    await new Promise(r=>setTimeout(r,100));
    document.querySelector('.title-preset.bold').click();
    await new Promise(r=>setTimeout(r,100));
    if(document.querySelectorAll('.clip').length!==1)throw Error('Title was not added');
    if(!document.querySelector('textarea'))throw Error('Title properties not shown');
    return {title:document.title,clips:document.querySelectorAll('.clip').length,properties:!!document.querySelector('textarea')};
   })()`);
      if (errors.length) throw Error(errors.join("\n"));
      console.log("UI SMOKE PASSED", JSON.stringify(result));
      if (process.env.NEXTERA_TEST_SCREENSHOT) {
        const image = await win.webContents.capturePage();
        fs.writeFileSync(process.env.NEXTERA_TEST_SCREENSHOT, image.toPNG());
      }
      app.exit(0);
    } catch (e) {
      console.error("UI SMOKE FAILED", e);
      app.exit(1);
    }
  });
});
setTimeout(() => {
  console.error("UI smoke timed out");
  app.exit(1);
}, 30000);
