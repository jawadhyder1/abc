# Validation record

Tested in the supplied Linux workspace. These results do not substitute for a
Windows acceptance test. There is no prebuilt or Windows-tested EXE in this delivery.

## Passed

- TypeScript strict type checking: `npm run typecheck`.
- Vite production renderer build: `npm run build`.
- JavaScript parse check for Electron main/preload.
- Python compile check for the worker and renderer.
- Five Node timeline unit tests: speed-aware split, reverse source ordering,
  word timing/keyframe interpolation, boundary no-op, caption text and preservation
  of unanimated property channels.
- Seven FFmpeg integration tests producing actual outputs:
  1. Audio-only timeline and mono 16 kHz extraction for recognition.
  2. Titles, colour/blur/sharpen/vignette/glitch, flip/rotation, a mosaic privacy box
     and interpolated position/opacity keyframes.
  3. MP4 dimensions, timeline duration, audio stream presence and preservation of an
     existing destination when validation fails.
  4. Decoded pixel checks for a black timeline gap and red source frames. Source-only
     corners remain red; the compiler does not insert branding.
  5. Portrait title-only export, boxed karaoke, word timing and animated text position.
  6. Reverse, speed, noise reduction, normalization, audio fades, overlapping tracks,
     background blur, and slide/zoom/wipe/dissolve exports.
  7. Invalid speed rejection, 4K dimension math, atempo decomposition and Roman Urdu
     dictionary/letter conversion.
- Actual faster-whisper tiny CPU-int8 English inference with `HF_HUB_OFFLINE=1`
  and `TRANSFORMERS_OFFLINE=1`, loading a predownloaded model by directory. A local
  speech sample was rendered through the timeline mix, transcribed into four-word
  captions and validated for positive durations and relative word timestamps.
  Recognized phrase included: "ask not".

The first inference attempt exposed an incompatible newer PyAV API. The final
requirements pin `av==16.0.1`; inference then passed. This is why the pinned
requirements should be used rather than installing arbitrary latest libraries.

## Not validated here

- Windows setup scripts executed on Windows, PyInstaller's Windows worker bundle,
  NSIS installer execution, clean-machine installation or uninstall.
- GPU encoders on actual NVIDIA, Intel or AMD hardware.
- Microphone permissions and recording under Windows.
- Recognition quality in Urdu/Hindi, Roman Urdu fluency, other model sizes.
- Production workloads, long timelines, variable-frame-rate phones, multi-hour
  audio, large media libraries, power-loss recovery, every codec or font.
- Pixel-identical browser and FFmpeg preview (not promised; use rendered preview).
- Desktop UI smoke test: attempted under headless Electron in the host environment,
  but the Electron process exited with SIGSEGV during platform initialization.
  The UI test is included for running on a normal GUI-capable machine. It is not
  recorded as a pass.

## Reproduce the normal checks on Windows

```bat
set PATH=%CD%\resources\bin;%PATH%
node --experimental-strip-types --test tests\editor.test.mjs
.venv\Scripts\python.exe -m unittest discover -s tests -v
npm run build
npm run test:ui
```

The speech test is skipped by default so normal tests don't download a model or
require personal audio. To enable it, install tiny, choose a local English WAV,
then run:

```bat
set NEXTERA_TEST_SPEECH=C:\Media\english-speech.wav
set HF_HUB_OFFLINE=1
set TRANSFORMERS_OFFLINE=1
.venv\Scripts\python.exe -m unittest discover -s tests -p test_captions.py -v
```

Optional `NEXTERA_EXPECT_PHRASE` asserts a known phrase in the supplied audio. The
validation sample used during development came from the whisper.cpp public sample
at https://github.com/ggml-org/whisper.cpp/tree/master/samples. It is not included in
the delivered package. The downloaded tiny model used for this test is also not
included in the source archive; install models explicitly with the setup script.

## First-run Windows acceptance checklist

1. Run Setup.cmd, download base, launch Start.cmd with internet disconnected.
2. Import MP4, WAV and PNG; confirm canvas playback and thumbnails.
3. Drag between tracks, trim both ends, split, delete, undo and redo.
4. Add a title and an overlapping transition; inspect Render preview.
5. Make captions in your spoken language; edit and round-trip SRT.
6. Record a short voiceover and test audio controls in rendered preview.
7. Save/open JSON; restart and try Recover autosave.
8. Export a short 1080p software MP4; play it in another video player.
9. Build the installer and test it in a clean Windows user profile.
10. Try hardware encoding and longer videos only after the basic workflow succeeds.
