# Scope and verification limits

This is a functional implementation with source, not a claim of Filmora-level
maturity. The following requirements are simplified or do not meet the request
literally. They are visible here so that you can evaluate the software honestly.

| Requirement | Implementation and limit |
|---|---|
| Only permissive licenses | Impossible with required FFmpeg. Original app/React/Electron/Zustand/faster-whisper use permissive licenses; FFmpeg, font and packaging runtime licenses are exceptions. |
| Fully offline | Runtime editing/transcription is local. Initial dependency and model acquisition needs internet unless you copy a prepared build from another computer. |
| Bundled FFmpeg | Windows setup retrieves binaries; the built EXE installer bundles them. The source ZIP itself includes fonts but does not include Windows FFmpeg, Python or models. |
| Identical live preview/export | Fast canvas preview is approximate. Rendered preview uses the same FFmpeg/ASS pipeline at reduced resolution. Pixel-level equality across resolutions is not promised. Sharpen/glitch, temperature, alpha, fonts, audio DSP and reverse are best checked in rendered preview. |
| Multi-track editing | Arbitrary numbered tracks, drag/move/trim, split, deletion, snapping and zoom. No ripple edit, group selection, track locking, nested sequences, waveform trim-aware remapping, or magnetic timeline. |
| Frame-accurate editing | Timeline uses fractional seconds and export follows FPS. Browser seeking and variable-frame-rate source decode are approximate. |
| Title ordering | All text overlays sit above video layers. Title tracks determine ordering among titles. |
| Text animation + keyframes | Linear position/scale/opacity keys. ASS text keyframes use per-frame events; combining them with animated fades/typewriter/karaoke may restart effects. Prefer one animation method per title. Active-word highlight uses timed ASS events and does not combine title keyframes. |
| Modern title library | Five original parameter presets, not a downloadable asset store. Styles share a simple layout engine; no nested typography or template browser with animated previews. |
| Blur/background blur | Gaussian filter and an aspect-fill blurred background. Privacy rectangle is axis-aligned in the clip's normalized canvas before its transform. It is not motion tracking. |
| Glitch/shake | Procedural RGB-shift pulses and sinusoidal shake; not complex displacement or optical-flow effects. |
| Transitions | Alpha transitions with track overlaps. Fade and dissolve use the same alpha implementation; slide/zoom/wipe are entrance effects. No single-track automatic xfade insertion. |
| Captions | Local faster-whisper CPU int8. Supports multilingual models and word timestamps. Quality depends on model/audio; hallucinations, punctuation, speaker separation and timing need review. No speaker diarization. |
| Roman Urdu | Dictionary/character transliteration, not fluent phonetic transliteration or English translation. Urdu consonants alone do not determine vowels. Manual correction is necessary. |
| Captions after timeline edits | Captions do not follow video edits automatically. Regenerate them after changing earlier video timing. Editing caption text clears word timing. |
| Caption styles | Active-word highlight, cumulative karaoke, box and outline. SRT exports only text and timing. Imported SRT does not contain word timestamps. |
| Noise/normalization | FFmpeg afftdn and single-pass loudnorm. Normalization is per clip, followed by a mix limiter; not a two-pass broadcast mastering pipeline. |
| Voiceover | Records the current default microphone and places the result at recording-start playhead. It does not provide input-device selection, punch-in, latency calibration or echo cancellation guarantees. |
| Hardware acceleration | Actual startup encoding probes for NVENC/QSV/AMF; final encode can still fail due to driver/size constraints. Filters and Whisper run on CPU. Select software encoding on failure. |
| 4K | Output preset is implemented. Performance and memory suitability are not guaranteed, especially with reverse, many overlaps and per-pixel alpha filters. |
| Proxy preview | Creates H.264 640-pixel files. No proxy cache eviction; proxies are references to local cached files. |
| Crash-safe | Debounced recovery snapshot, atomic project writes and staged exports reduce loss. Not transactional across power failure; last 1.5 seconds or an in-flight save may be lost. No guarantee of zero crashes. |
| 2–3 clicks for every feature | Frequent actions are direct; model installation, recovery, detailed keyframes and multi-parameter styling take more steps. |
| Drag everywhere | OS file import, media cards, timeline move/trim and track moves are supported. Text/box positioning uses click-to-position and sliders; not every panel is draggable. |
| Windows ready | Source, scripts and installer configuration provided. Actual Windows setup, packaging, microphone, font shaping and hardware acceptance tests remain necessary. |

Keep a copy of your original media and save the project manually before substantial
changes. This version is best suited to short personal tutorials while you test it.
