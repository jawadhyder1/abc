@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File scripts\build-worker.ps1
if errorlevel 1 goto failed
call npm run dist
if errorlevel 1 goto failed
echo Installer created in the release folder.
pause
exit /b 0
:failed
echo BUILD FAILED. Read the error above.
pause
exit /b 1
